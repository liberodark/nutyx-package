// TEXT_FR.H - French Text for TeraByte Unlimited's IFD/IFL/IFWC Products
//
// Copyright (c) 2007 TeraByte, Inc.  All Rights Reserved.
//

#include "text.h"

#define tY 'Y'
#define tN 'N'

#if defined(DOS_GUI) || defined(LINUX_GUI)
const TCHAR tEmptyString[]=_T("");
#endif

const TCHAR tUsage[]=_T("Utilisation : image [action] [options]") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                    _T("Pour d�sactiver une option, utiliser " SLASH "opt:0") NEWLINE _T("\0")
                    _T("[action]") NEWLINE _T("\0")
                    _T("  " SLASH "b     Sauvegarder.") NEWLINE _T("\0")
                    _T("  " SLASH "r     Restaurer.") NEWLINE _T("\0")
                    _T("  " SLASH "v     V�rifier.") NEWLINE _T("\0")
                    _T("  " SLASH "copy  Copier.") NEWLINE _T("\0")
                    _T("  " SLASH "l     Lister.") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                    _T("[options]") NEWLINE _T("\0")
                    _T("  G�n�raux :") NEWLINE _T("\0")
                    _T("   " SLASH "uvl       Utiliser les noms de volumes.") NEWLINE _T("\0")
                    _T("   " SLASH "aoe       Aligner sur la fin.") NEWLINE _T("\0")
                    _T("   " SLASH "seq       Utiliser la s�quence des volumes.") NEWLINE _T("\0")
                    _T("   " SLASH "con       Console IO.") NEWLINE _T("\0")
                    _T("   " SLASH "nocan     D�sactiver l'annulation.") NEWLINE _T("\0")
                    _T("   " SLASH "log       Activer les traces.") NEWLINE _T("\0")
                    _T("   " SLASH "logfile   Enregistrer traces dans un fichier (selon chemin de l'OS).") NEWLINE _T("\0")
                    _T("   " SLASH "relax     Recherche simple du lecteur source.") NEWLINE _T("\0")
                   #if defined(WIN32)
                    _T("   " SLASH "ignsvc    Ignorer services.ins (contr�le des services).") NEWLINE _T("\0")
                   #else
                    _T("   " SLASH "tz        D�finir la zone horaire, par ex. PST8PDT.") NEWLINE _T("\0")
                   #endif
                   #if defined(__MSDOS__)
                    _T("   " SLASH "atapidma  Support UDMA ATAPI.") NEWLINE _T("\0")
                    _T("   " SLASH "uhci      Acc�der aux contr�leurs USB 1.1 (UHCI) (d�faut).") NEWLINE _T("\0")
                    _T("   " SLASH "usbign    Masquer les contr�leurs USB ignor�s.") NEWLINE _T("\0")
                    _T("   " SLASH "usblio    Limiter les entr�es/sorties en USB.") NEWLINE _T("\0")
                    _T("   " SLASH "biosata   Utiliser le BIOS (direct) comme modificateur par d�faut.") NEWLINE _T("\0")
                    _T("   " SLASH "bgp       Avancement de la mise � jour en arri�re plan.") NEWLINE _T("\0")
                    _T("   " SLASH "exo       DOS �tendu (supporte 4 GiB).") NEWLINE _T("\0")
                   #endif
                    _T("   " SLASH "u[nym]    Demande impr�vue (n=annuler, y=ok, m=pas d'invite pour les m�dias).") NEWLINE _T("\0")
                    _T("   " SLASH "msg       Message personnalis�.") NEWLINE _T("\0")
                    _T("   " SLASH "kfb       Conserver sauvegardes incompl�tes.") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                   #if defined(WIN32)
                    _T("  PHYLock :") NEWLINE _T("\0")
                    _T("   " SLASH "plur      Utiliser les param�tres PHYLock du registre et non ceux de ini/env.") NEWLINE _T("\0")
                    _T("   " SLASH "pldis     D�sactiver l'utilisation de PHYLock.") NEWLINE _T("\0")
                    _T("   " SLASH "plifnl    Utiliser PHYLock si n�c�ssaire.") NEWLINE _T("\0")
                    _T("   " SLASH "plrell    Utiliser les verrouillages PHYLock et OS.") NEWLINE _T("\0")
                    _T("   " SLASH "plvolf    Essayer de flusher le volume.") NEWLINE _T("\0")
                    _T("   " SLASH "pldisk    Essayer d'utiliser le cache disque.") NEWLINE _T("\0")
                    _T("   " SLASH "plmem     Option m�moire.") NEWLINE _T("\0")
                    _T("   " SLASH "pldcs     Taille du cache du disque.") NEWLINE _T("\0")
                    _T("   " SLASH "plwft     �crire le temps d'attente en millisecondes.") NEWLINE _T("\0")
                    _T("   " SLASH "plmwt     Temps d'attente maximal en minutes.") NEWLINE _T("\0")
                    _T("   " SLASH "plcs      Taille de la m�moire cache RAM.") NEWLINE _T("\0")
                   #endif
                    NEWLINE _T("\0")
                    _T("  Options communes :") NEWLINE _T("\0")
                    _T("   " SLASH "base      Nom du fichier de l'image de base.") NEWLINE _T("\0")
                    _T("   " SLASH "f         Nom du fichier de l'image.") NEWLINE _T("\0")
                    _T("   " SLASH "d         Num�ro de disque et partition (d@p).") NEWLINE _T("\0")
                    _T("   " SLASH "pw        Mot de passe.") NEWLINE _T("\0")
                   #if defined(__MSDOS__)
                    _T("   " SLASH "te        Terminer �mulation.") NEWLINE _T("\0")
                   #endif
                   #if !defined(WIN32)
                    _T("   " SLASH "mo        Menu int�ractif disponible.") NEWLINE _T("\0")
                   #endif
                   #if !defined(WIN32) || defined(_CONSOLE)
                    _T("   " SLASH "fs        Lister l'espace libre (liste action).") NEWLINE _T("\0")
                   #endif
                    _T("   " SLASH "rb        Red�marrage.") NEWLINE _T("\0")
                    _T("   " SLASH "npt       Pas de table de partitions sur le lecteur.") NEWLINE _T("\0")
                    _T("   " SLASH "anpt      Consid�rer la table des partitions absente si le MBR est vide.") NEWLINE _T("\0")
                    _T("   " SLASH "nptrm     Appliquer seulement les options NPT aux m�dias amovibles.") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                    _T("  Sauvegarde :") NEWLINE _T("\0")
                    _T("   " SLASH "cmz       Utiliser la methode de fermeture alternative pour les CDs.") NEWLINE _T("\0")
                    _T("   " SLASH "cdws      Vitesse de gravure du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "max       Taille maximale des fichiers.") NEWLINE _T("\0")
                    _T("   " SLASH "raw       Mode brut.") NEWLINE _T("\0")
                    _T("   " SLASH "skp       Ignorer le fichier d'�change.") NEWLINE _T("\0")
                    _T("   " SLASH "skh       Ignorer le fichier d'hibernation.") NEWLINE _T("\0")
                    _T("   " SLASH "v         V�rifier le fichier apr�s sauvegarde.") NEWLINE _T("\0")
                    _T("   " SLASH "vb        V�rifier le fichier octet-par-octet apr�s sauvegarde.") NEWLINE _T("\0")
                    _T("   " SLASH "vpd       V�rifier par disque.") NEWLINE _T("\0")
                    _T("   " SLASH "comp      Type de compression.") NEWLINE _T("\0")
                    _T("   " SLASH "enc       Type de cryptage.") NEWLINE _T("\0")
                    _T("   " SLASH "noej      Pas d'�jection automatique du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "cdrs      Vitesse de lecture du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "iobs      Optimisation ajustable.") NEWLINE _T("\0")
                    _T("   " SLASH "err       Ignorer les erreurs d'entr�e/sortie.") NEWLINE _T("\0")
                    _T("   " SLASH "mp        Op�ration multi-passages.") NEWLINE _T("\0")
                    _T("   " SLASH "mf        Op�ration multi-fichiers.") NEWLINE _T("\0")
                    _T("   " SLASH "desc      Description de la sauvegarde.") NEWLINE _T("\0")
                    _T("   " SLASH "purge     Supprimer les fichier sur le dossier cible.") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                    _T("  Restauration :") NEWLINE _T("\0")
                    _T("   " SLASH "o         �crire sur la cible sans confirmation.") NEWLINE _T("\0")
                    _T("   " SLASH "clr       Effacer le MBR existant.") NEWLINE _T("\0")
                    _T("   " SLASH "rb[01]    Red�marrage (0=Non, 1=Oui).") NEWLINE _T("\0")
                    _T("   " SLASH "sp        ID des partitions � restaurer.") NEWLINE _T("\0")
                    _T("   " SLASH "sig       Restaurer la signature disque NT.") NEWLINE _T("\0")
                    _T("   " SLASH "ohd       Conserver la r�f�rence du secteur de d�marrage.") NEWLINE _T("\0")
                    _T("   " SLASH "v         V�rifier l'image avant restauration.") NEWLINE _T("\0")
                    _T("   " SLASH "a         Marquer la partition Active.") NEWLINE _T("\0")
                    _T("   " SLASH "t         �crire un code MBR standard.") NEWLINE _T("\0")
                    _T("   " SLASH "e         Restaurer sur la m�me entr�e MBR.") NEWLINE _T("\0")
                    _T("   " SLASH "rft       Restaurer la premiere piste.") NEWLINE _T("\0")
                    _T("   " SLASH "fts       Nombre de secteurs � restaurer.") NEWLINE _T("\0")
                    _T("   " SLASH "s         Ajuster � l'espace disponible.") NEWLINE _T("\0")
                    _T("   " SLASH "x         Agrandir � l'espace disponible.") NEWLINE _T("\0")
                    _T("   " SLASH "m         Premier espace disponible.") NEWLINE _T("\0")
                    _T("   " SLASH "kf        Espace libre (MiB) � conserver.") NEWLINE _T("\0")
                    _T("   " SLASH "noej      Pas d'�jection automatique du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "cdrs      Vitesse de lecture du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "iobs      Optimisation ajustable.") NEWLINE _T("\0")
                    _T("   " SLASH "err       Ignorer les erreurs d'entr�e/sortie.") NEWLINE _T("\0")
                    _T("   " SLASH "mp        Op�ration multi-passages.") NEWLINE _T("\0")
                    _T("   " SLASH "cds       Chercher lecteur CD/DVD contenant l'image.") NEWLINE _T("\0")
                    _T("   " SLASH "og        Utiliser la g�om�trie d'origine.") NEWLINE _T("\0")
                    _T("   " SLASH "c         Dernier cylindre.") NEWLINE _T("\0")
                    _T("   " SLASH "h         Derni�re t�te.") NEWLINE _T("\0")
                    _T("   " SLASH "s         Secteurs par piste.") NEWLINE _T("\0")
                    _T("   " SLASH "a2k       Aligner sur 1MiB.") NEWLINE _T("\0")
                    _T("   " SLASH "ahs       Aligner sur la fin du MBR HS.") NEWLINE _T("\0")
                    _T("   " SLASH "ahst      Aligner sur MBR HS si coupure.") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                    _T("  V�rification :") NEWLINE _T("\0")
                    _T("   " SLASH "sp        ID des partitions � v�rifier.") NEWLINE _T("\0")
                    _T("   " SLASH "noej      Pas d'�jection automatique du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "cdrs      Vitesse de lecture du CD.") NEWLINE _T("\0")
                    _T("   " SLASH "iobs      Optimisation ajustable.") NEWLINE _T("\0")
                    _T("   " SLASH "mp        Op�ration multi-passages.") NEWLINE _T("\0")
                    NEWLINE _T("\0")
                    _T("  Copie :") NEWLINE _T("\0")
                    _T("   " SLASH "sd        Lecteur source (d@p).") NEWLINE _T("\0")
                    _T("   " SLASH "td        Lecteur cible (d@p).") NEWLINE _T("\0")
                    _T("   " SLASH "raw       Mode brut.") NEWLINE _T("\0")
                    _T("   " SLASH "skp       Ignorer le fichier d'�change.") NEWLINE _T("\0")
                    _T("   " SLASH "skh       Ignorer le fichier d'hibernation.") NEWLINE _T("\0")
                    _T("   " SLASH "o         �crire sur la cible sans confirmation.") NEWLINE _T("\0")
                    _T("   " SLASH "clr       Effacer le MBR existant.") NEWLINE _T("\0")
                    _T("   " SLASH "rb[01]    Red�marrage (0=Non, 1=Oui).") NEWLINE _T("\0")
                    _T("   " SLASH "sig       Copier la signature disque NT.") NEWLINE _T("\0")
                    _T("   " SLASH "csig      Modifier la signature disque NT.") NEWLINE _T("\0")
                    _T("   " SLASH "ohd       Conserver la r�f�rence du secteur de d�marrage.") NEWLINE _T("\0")
                    _T("   " SLASH "a         Marquer la partition Active.") NEWLINE _T("\0")
                    _T("   " SLASH "t         �crire un code MBR standard.") NEWLINE _T("\0")
                    _T("   " SLASH "e         Copier sur la m�me entr�e MBR.") NEWLINE _T("\0")
                    _T("   " SLASH "rft       Copier la premiere piste.") NEWLINE _T("\0")
                    _T("   " SLASH "fts       Nombre de secteurs � copier.") NEWLINE _T("\0")
                    _T("   " SLASH "s         Ajuster � l'espace disponible.") NEWLINE _T("\0")
                    _T("   " SLASH "x         Agrandir � l'espace disponible.") NEWLINE _T("\0")
                    _T("   " SLASH "m         Premier espace disponible.") NEWLINE _T("\0")
                    _T("   " SLASH "kf        Espace libre (MiB) � conserver.") NEWLINE _T("\0")
                    _T("   " SLASH "err       Ignorer les erreurs d'entr�e/sortie.") NEWLINE _T("\0")
                    _T("   " SLASH "og        Utiliser la g�om�trie d'origine.") NEWLINE _T("\0")
                    _T("   " SLASH "c         Dernier cylindre.") NEWLINE _T("\0")
                    _T("   " SLASH "h         Derni�re t�te.") NEWLINE _T("\0")
                    _T("   " SLASH "s         Secteurs par piste.") NEWLINE _T("\0")
                    _T("   " SLASH "a2k       Aligner sur 1MiB.") NEWLINE _T("\0")
                    _T("   " SLASH "ahs       Aligner sur la fin de MBR HS.") NEWLINE _T("\0")
                    _T("   " SLASH "ahst      Aligner sur MBR HS si coupure.") NEWLINE _T("\0");


const TCHAR tCLInvalidParameterX[]=_T("Param�tre incorrect : %s") NEWLINE;
const TCHAR tCLInvalidParamXActionRequired[]=_T("Param�tre '%s' trouv� avant l'op�ration") NEWLINE;
const TCHAR tCLDeviceNotFound[]=_T("P�riph�rique non trouv�.") NEWLINE;
const TCHAR tCLParameterX[]=_T("Param�tre : %s") NEWLINE;
const TCHAR tCLMissingParameterX[]=_T("Param�tre oubli� : %s") NEWLINE;
const TCHAR tCLSourcePartitionNotFound[]=_T("Partition source non trouv�e dans la sauvegarde.") NEWLINE;
const TCHAR tCLTargetDeviceNotFound[]=_T("P�riph�rique cible non trouv�") NEWLINE;
const TCHAR tCLResizeValueInvalid[]=_T("Taille incorrecte.") NEWLINE;
const TCHAR tCLNonPartitionDeviceSelected[]=_T("Ce disque ne contient pas de partitions") NEWLINE;
#if defined(WIN32)
const TCHAR tCLCantDirectSaveToSameAsBackupSource[]=
      _T("Le syst�me de fichiers cible ne peut pas �tre le m�me que celui de la source,") NEWLINE
      _T("sauf si PHYLock est actif et que vous utiliser le modificateur 'A'.");
#endif

#if defined(__LINUX__)
   const TCHAR tDetectionCompletedWithXChanged[]=_T("D�tection termin�e") NEWLINE _T("Net Change: %i");
#endif

const TCHAR tDeviceNotAllowed[]=_T("P�riph�rique s�lectionn� non autoris�");
const TCHAR tBaseFilename[]=_T("Nom de la sauvegarde de base");
const TCHAR tBaseFilenameNotAllowed[]=_T("Nom de la sauvegarde de base incorrect.");
const TCHAR tTargetPartitionNotAllowed[]=_T("Partition cible non autoris�e.");
const TCHAR tSourcePartitionNotAllowed[]=_T("Partition source non autoris�e.");
const TCHAR tInvalidEncryptOption[]=_T("Option de cryptage incorrecte.");

const TCHAR tPartListTitle1L[]=_T("Dr       Nom          Taille    ");
const TCHAR tPartListTitle2L[]=_T("-- ---------------- ----------- ");
const TCHAR tPartListTitle1M[]=_T("    Libre   ");
const TCHAR tPartListTitle2M[]=_T("----------- ");
const TCHAR tPartListTitle1R[]=_T("Typ   ID    Syst. de fichiers") NEWLINE;
const TCHAR tPartListTitle2R[]=_T("--- ------ ------------------") NEWLINE;

const TCHAR tDeleteExistingFiles[]=_T("Supprimer le(s) fichier(s) existant(s) sur la cible ?");
const TCHAR tPressEnterToContinue[]=_T("Appuyer sur Entr�e pour continuer...");

//-------------------
const TCHAR tOutOfMemory[]=_T("M�moire insuffisante");
const TCHAR tUnableToMountFS[]=_T("Impossible d'ouvrir le syst�me de fichier.");
const TCHAR tUnableToReadFile[]=_T("Impossible de lire les donn�es du fichier !");
const TCHAR tUnableToWriteFile[]=_T("Impossible d'�crire des donn�es sur le fichier !");
const TCHAR tUnableToWriteFileFull[]=_T("Plus d'espace libre pour �crire le fichier !");
const TCHAR tCancelInvalidImage[]=_T("Annulation de l'op�ration, l'image est invalide.");
const TCHAR tImageFailed[]=_T("L'image est corrompue. Merci de red�marrer !");
const TCHAR tUnableToAdd[]=_T("Impossible d'ajouter l'entr�e");
const TCHAR tUpdateFailed[]=_T("Impossible de mettre � jour l'entr�e");
const TCHAR tDataLost[]=_T("Le secteur de d�marrage a �t� effac�.");
const TCHAR tUnableToUpdateBS[]=_T("�chec de la mise � jour du secteur de d�marrage");
const TCHAR tImageComplete[]=_T("La %s s'est termin�e avec succ�s.");
const TCHAR tImageCompleteWithBadSectors[]=_T("La %s s'est termin�e, mais a rencontr� %llu secteur(s) incorrect(s) and %llu byte-for-byte error(s).");
const TCHAR tCompletedBackup[]=_T("Sauvegarde termin�e");
const TCHAR tCompletedRestore[]=_T("Restauration termin�e");
const TCHAR tCompletedValidate[]=_T("V�rification termin�e");
const TCHAR tCompletedCopy[]=_T("Copie termin�e");
const TCHAR tBadSectorsXXFoundSeqX[]=_T("Mauvais secteurs - Lecture :%llu ; �criture :%llu (%llu)");
const TCHAR tAnErrorHasOccured[]=_T("Une erreur est survenue %s sur le disque dur. (Compteur:%u LBA:%llu)");
const TCHAR tReadingFrom[]=_T("lecture de");
const TCHAR tWritingTo[]=_T("�criture sur");
const TCHAR tOpenFailed[]=_T("Impossible d'ouvrir le fichier");
const TCHAR tCreateFailed[]=_T("Impossible de cr�er le fichier");
const TCHAR tCreatePathFailed[]=_T("Impossible de cr�er le chemin");
const TCHAR tPathNotFound[]=_T("Chemin non trouv�");
#if defined(WIN32)
const TCHAR tPHYLockRangeFailed[]=_T("Erreur lors de la pr�paration de PHYLock");
const TCHAR tPHYLockCacheFailed[]=_T("PHYLock n'a pas pu mettre en cache les changements. Merci d'augmenter la taille du cache dans les param�tres.");
const TCHAR tUnableToMountFSInUse[]=_T("Le lecteur est en cours d'utilisation et ne peut pas �tre acc�d� en direct.");
const TCHAR tVSSDeviceError[]=_T("Le lecteur VSS n'est pas plus utilisable. Cela est probablement d� � une erreur de graveur VSS ou de fournisseur VSS.");
const TCHAR tWindowsFSFailed[]=_T("�chec de l'utilisation du support Windows FS.");
#endif

const TCHAR tResizingXMBXToXMBX[]=_T("Ajustement de la taille de %uMiB (%llu) � %uMiB (%llu)");
const TCHAR tResizeCompleted[]=_T("Ajustement de la taille termin�.");
const TCHAR tRestoredPartitionWillBeDeleted[]=_T("La partition cible sera supprim�e.");
const TCHAR tPleaseRunFSCheck[]=_T("Merci de lancer une v�rification du syst�me de fichier.");
const TCHAR tResizeFailed[]=_T("�chec du r�ajustement (%u/%u/%u)") NEWLINE _T("%s");
const TCHAR tResizeExpandFailed[]=_T("Impossible d'�tendre la partition (%u/%u/%u)") NEWLINE _T("%s");
const TCHAR tUnableToSaveSettings[]=_T("Les param�tres ne peuvent pas �tre enregistr�es.") NEWLINE;
const TCHAR tSaveSettingsCompleted[]=_T("Les param�tres ont �t� enregistr�s en tant que d�fauts.") NEWLINE;

const TCHAR tMBRFullXAllowed[]=_T("La table des partitions sur le disque cible n'est pas assez large (%u libre) pour contenir la partition s�lectionn�e. Veuillez modifier le type de disque.");
const TCHAR tMBRFull[]=_T("Impossible d'ajouter des partitions.");
const TCHAR tEntryProblem[]=_T("Impossible de trouver l'entr�e de la partition.");
const TCHAR tHDProblem[]=_T("Un probl�me est survenu lors de l'acc�s au disque.");
const TCHAR tFileProblem[]=_T("Impossible d'ouvrir ou de lire les donn�es du fichier image.");
const TCHAR tOccupied[]=_T("La restauration d�passera les partitions existantes.");
const TCHAR tFileFormatInvalid[]=_T("Le fichier n'est pas une image valide.");
const TCHAR tFileXFormatInvalidX[]=_T("Le fichier %s n'est pas une image valide (%u).");
const TCHAR tUnableToReadDevice[]=_T("Impossible de lire les donn�es du p�riph�rique");
const TCHAR tUnableToWriteDevice[]=_T("Impossible d'�crire sur le p�riph�rique");
const TCHAR tUnableToAccessMedia[]=_T("Imposible d'acc�der au m�dia");
const TCHAR tUnableToAccessDevice[]=_T("Impossible d'acc�der au p�riph�rique");
const TCHAR tUnableToUpdateMBR[]=_T("Impossible d'�crire le MBR");
const TCHAR tExistingEntryWarning[]=_T("ATTENTION : Toutes les donn�es dans %s (%s) sur le disque HD%i%s seront effac�es.") NEWLINE;
const TCHAR tAreYouSureContinueRestore[]=_T("�tes-vous sur de vouloir continuer (O/N)? ");
const TCHAR tExistingEntriesOverwriteWarn[]=_T("ATTENTION : Les partitions suivantes de HD%i%s seront effac�es :");
const TCHAR tOverwriteExistingItems[]=_T("ATTENTION : Voulez-vous �craser les partitions existantes (O/N) ? ");
const TCHAR tSystemWillNowReboot[]=_T("Le syst�me va red�marrer pour permettre � l'OS de prendre en compte les changements.");
const TCHAR tWontFit[]=_T("La destination s�lectionn�e n'est pas assez large.");
const TCHAR txMBNeeded[]=_T("(%u MiB) n�cessaires.");
#if defined(WIN32)
const TCHAR tNoHD[]=_T("Aucun disque utilisable !") NEWLINE
                    NEWLINE
                    _T("Vous devez lancer ce programme avec les droits") NEWLINE
                    _T("administrateur sur cette machine.") NEWLINE
                    NEWLINE
                    _T("Pour cela, cliquez-droit sur l'ic�ne du programme") NEWLINE
                    _T("et choisissez ""Lancer en tant que..."".");
#else
const TCHAR tNoHD[]=_T("Aucun disque utilisable !") NEWLINE _T("Appuyez sur Entr�e et r�essayez dans quelques secondes.");
#endif
const TCHAR tNoHDSimple[]=_T("Simple Operations requires an additional HD that was not found!") NEWLINE NEWLINE _T("NOTE: \"Simple Operations\" can be disabled in Settings.");
const TCHAR tRestored[]=_T("Restaur."); // 8 chars max
const TCHAR tByteByByteFailed[]=_T("�chec de la v�rification octet-par-octet.%s");
const TCHAR tRebootSkipped[]=_T("Annulation du red�marrage !") NEWLINE;
const TCHAR tNoInteractWithConsoleIO[]=_T("CONSOLEIO : session int�ractive non autoris�e.") NEWLINE;
const TCHAR tNewMediaNeededButAllocated[]=_T("Un nouveau m�dia �tait demand�, mais le m�dia est en cours d'utilisation.");
const TCHAR tNotAllFilesDeleted[]=_T("Impossible de supprimer tous les fichiers de la liste.");
const TCHAR tCantContinueFoundXDevMatches[]=_T("Impossible de d�terminer le lecteur source.") NEWLINE _T("%u lecteurs trouves.");
const TCHAR tXMBUsedXMBFreeXMBLastLBAXtoX[]=_T("%s utilis�s") NEWLINE _T("%s libres") NEWLINE _T("%s � restaurer") NEWLINE NEWLINE _T("LBA: %llu-%llu");
const TCHAR tLBAXtoX[]=_T("LBA: %llu-%llu");
const TCHAR tInvalidFSIDType[]=_T("Le syst�me de fichiers de la partition ne correspond pas � son identifiant.") NEWLINE _T("Voulez-vous corriger cette erreur ?");
const TCHAR tPathNotFoundCreate[]=_T("Le chemin n'a pas �t� trouv�.") NEWLINE _T("Voulez-vous le cr�er ?");
const TCHAR tMultiVorPTargetNoGood[]=_T("La cible ne peut pas recevoir plusieurs partitions en m�me temps car d'autres partitions existent d�j�.");

const TCHAR tPartialVorPsListed[]=_T(" - Partiel");
const TCHAR tVorPIDXNotFound[]=_T("Entr�e 0x%02X non trouv�e.");
const TCHAR tTargetOverlapsSourceX[]=_T("La cible pour la restauration contient le fichier de sauvegarde source.") NEWLINE _T("%s");
const TCHAR tCopyTargetSameAsSource[]=_T("La cible pour la copie va �craser ou supprimer la source.");
const TCHAR tTargetSectorSizeXNeedsToBeX[]=_T("Le lecteur cible s�lectionn� contient %u octets alors que %u octets sont n�cessaires pour la restauration.");
#if defined(__MSDOS__)
const TCHAR tWaitingForUSBDevices[]=_T("Patientez %02u secondes : d�tection des lecteurs USB") NEWLINE
									_T("(appuyez sur Espace pour ignorer)") NEWLINE
                                    NEWLINE
                                    HIGHLIGHT _T("<< Notice sur les claviers USB >>") HIGHLIGHT NEWLINE
                                    _T("Les claviers USB peuvent ne pas fonctionner lorsque IFD prend le control des") NEWLINE
                                    _T("ports USB. Se r�ferez � l'article KB 349 ou utilisez Image For Linux.");

const TCHAR tNoDOSBox[]=NEWLINE _T(">>Ce programme doit �tre lanc� sous DOS et non depuis une boite DOS.<<") NEWLINE;
const TCHAR tSavingLog[]=_T("Enregistrement des traces...");
const TCHAR tSavingLogHang[]=_T("Enregistrement des traces...") NEWLINE
                             NEWLINE
                             _T("(Le BIOS peut verrouiller le syst�me)");

#endif

const TCHAR tErrCDFilenameTooLong[]=_T("Nom trop long. Il ne doit pas d�passer 64 caract�res.");
const TCHAR tNoLockForDelete[]=_T("La partition est en cours d'utilisation et ne peut pas �tre supprim�e.");
const TCHAR tAreYouSureYouWantToChgPartLayout[]=_T("�tes-vous s�r de vouloir modifier le type de partionnement ?");
const TCHAR tNoExtendedOnGPTDisk[]=_T("Une partition �tendue ne peut pas �tre utilis�e sur un disque GPT.");
const TCHAR tFailedPartLayoutChg[]=_T("Le partionnement ne peut pas �tre modifi� pour correspondre � la s�lection.");
const TCHAR tEFISystemRequiresGPT[]=_T("Votre demande est ignor�e car les syst�mes EFI n�cessitent le GPT.");

#if defined(DOS_GUI) || defined(LINUX_GUI)
const TCHAR tSelectGPTEMBRMBR[]=_T("Cette option vous permet de modifier le type de partitionnement d'un disque.") NEWLINE NEWLINE
                                _T("Certains indicateurs sp�cifiques ne sont pas conserv�s lors d'une conversion d'un disque GPT ou EMBR vers un autre format.") NEWLINE
                                _T("ATTENTION : le format GPT n'est pas appropri� pour les disques de d�marrage des PCs standards. Le format GPT")
                                _T("permet le partitionnement au dessus de 2TiB et ne devrait �tre utilis� que sur les disques d�di�s aux donn�es.") NEWLINE;
const TCHAR tSelectPartitionLayout[]=_T("S�lectionnez le type de partionnement");
#else
const TCHAR tSelectGPTEMBRMBR[]=_T("Cette option vous permet de modifier le type de partitionnement d'un disque.") NEWLINE NEWLINE
                                _T("Certains indicateurs sp�cifiques ne sont pas conserv�s lors d'une conversion d'un disque GPT ou EMBR vers un autre format.") NEWLINE
                                _T("ATTENTION : le format GPT n'est pas appropri� pour les disques de d�marrage des PCs standards. Le format GPT")
                                _T("permet le partitionnement au dessus de 2TiB et ne devrait �tre utilis� que sur les disques d�di�s aux donn�es.") NEWLINE
                                _T("Saisissez le type de partionnement ")
                                HIGHLIGHT _T("GPT") HIGHLIGHT _T(", ") HIGHLIGHT _T("EMBR") HIGHLIGHT _T(" ou ") HIGHLIGHT _T("MBR") HIGHLIGHT _T(" a utiliser:");
#endif

const TCHAR tConvertNonPartToMBRDataloss[]=_T("Cette option permet de partitionner un disque non-partionn�.") NEWLINE NEWLINE
                                           _T("ATTENTION : Toutes les donn�es du lecteur seront supprim�es !") NEWLINE NEWLINE
                                           _T("�tes-vous s�r de vouloir continuer ? (O/N)");

const TCHAR tNewVersionRequired[]=_T("Ce fichier image n�cessite une version plus r�cente de ce programme.");
const TCHAR tDuplicateFound[]=_T("Plus d'un �l�ment trouv�s.");

//-------------------
const TCHAR tDevice[]=_T("P�riph�rique");
const TCHAR tFilename[]=_T("Nom de fichier");
const TCHAR tDetails[]=_T("D�tails");
const TCHAR tFix[]=_T("Corriger");
const TCHAR tVolume[]=_T("Volume");
const TCHAR tPartition[]=_T("Partition");
const TCHAR tNotice[] = _T("Information");
const TCHAR tProgress[]=_T("Progression");
const TCHAR tDone[]=_T("effectu�");
const TCHAR tPassword[]=_T("Mot de passe");
const TCHAR tIndividualItems[]=_T("�l�ment individuel");

//-------------------
const TCHAR tInsertNextMediaXForFileX[]=_T("Ins�rez le m�dia %u contenant le fichier %s");
const TCHAR tMediaFullInsertNextDiskForX[]=_T("Pas d'espace libre sur le m�dia.") NEWLINE _T("Ins�rer un m�dia pour le fichier %s");
const TCHAR tInsertMediaForVolumeX[]=_T("Ins�rez un m�dia pour le volume %s");
const TCHAR tCanContinueWithDataLoss[]=NEWLINE _T("Do not abort if you want to ignore these errors.") 
                                       NEWLINE 
                                       NEWLINE _T("Do you want to abort the operation (Y/N)? ");
const TCHAR tRUSureUWantToCancel[]=_T("�tes-vous s�r de vouloir annuler (O/N) ?");
const TCHAR tGetName[]=_T("Nom de la partition restaur�e : ");
const TCHAR tOkayToShutDown[]=_T("Vous devez �teindre votre ordinateur...");
const TCHAR tAreYouSureYouWantToSkipReboot[]=_T("Ignorer le red�marrage peut entra�ner des erreurs.") NEWLINE
                                             _T("�tes-vous s�r d'annuler le red�marrage ?");
const TCHAR tEnterSizeForExtended[]=_T("Entrez la taille en MiB");
const TCHAR tCreateExtended[]=_T("Cr�er une partition �tendue");
const TCHAR tAreYouSureYouWantToDeleteVorP[]=_T("ATTENTION : Toutes les donn�es sur la partition s�lectionn�e") NEWLINE
                                             _T("seront effac�es. �tes-vous s�r de vouloir continuer ?");
const TCHAR tAllPartitionsWillBeDeletedFromXX[]=_T("Toutes les partitions existantes seront effac�es sur le lecteur") NEWLINE
                                                _T("cible (%s - %u MiB). �tes-vous s�r de vouloir continuer ?");
const TCHAR tPressSpaceForMenu[]=_T("Appuyez sur <") HIGHLIGHT _T("Espace") HIGHLIGHT _T("> pour utiliser l'interface menu") NEWLINE
                                 _T("ou patientez que %s d�marre...");
const TCHAR trestore[]="restauration";
const TCHAR tbackup[]="sauvegarde";
const TCHAR tvalidate[]="v�rification";
const TCHAR tcopy[]="copie";

//-------------------
const TCHAR tReinsertDiscX[]=_T("Merci de r�ins�rer le disque %u");
const TCHAR tInsertCDx[]=_T("Merci d'ins�rer le disque num�ro %i puis d'appuyer sur Entr�e.");
const TCHAR tCDFromWrongSet[]=_T("Le disque n'appartient pas � ce lot.");
//const TCHAR tPCTooSlow[]=_T("PC is too slow to image to CD/DVD.");
const TCHAR tEraseMedia[]=_T("Le disque n'est pas vide. L'effacer (O/N) ?");
const TCHAR tInsertBlankMedia[]=_T("Ins�rer un disque vide pour le volume %u puis appuyer sur Entr�e");
const TCHAR tInsertLastDisc[]=_T("Merci d'ins�rer le dernier disque du lot et appuyer sur Entr�e");
const TCHAR tUnableToReadCD[]=_T("Impossible de lire les donn�es du disque !");
const TCHAR tFailedDiscValidate[]=_T("�chec lors de la v�rification du disque !");
const TCHAR tErrorWritingCD[]=_T("Erreur lors de l'�criture sur le disque !");
const TCHAR tDriveErrorReport[]=_T("Above is the error reported by the drive with the last three") NEWLINE
                                _T("codes representing the sense key, asc, and ascq respectively.") NEWLINE
                                _T("A lens cleaning, firmware update or different media is suggested.");
const TCHAR tCDDeviceNotFound[]=_T("Le lecteur CD/DVD %u n'a pas �t� trouv�.");
const TCHAR tCDNotWritable[]=_T("Le lecteur CD/DVD s�lectionn� est en lecture seule.");
const TCHAR tUnableToReadVorPsCDLastErrX[]=_T("Recuperer les metadonn�es depuis le dernier disque (%u).");
const TCHAR tNoCD[]=_T("Aucun lecteur CD/DVD accessible !") NEWLINE _T("Appuyez sur Entr�e et r�essayez dans quelques secondes.");
const TCHAR tCDWontBoot[]=_T("NOTE : Les disques cr��s ne seront pas amor�ables,") NEWLINE
                          _T("car le fichier CDBOOT.INS n'a pas �t� trouv�") NEWLINE
                          _T("ou il contient des r�f�rences incorrectes.");


const TCHAR tConfirmDeleteOfFilesXDaysOld[]=_T("Confirmez le nettoyage des fichiers qui ont au moins %u jour(s).");
const TCHAR tPurge[]=_T("Purge");
const TCHAR tCompressionLevelNotOptimized[]=_T("Merci de noter que vous avez choisi une m�thode de compression evolu�e qui n'a pas encore �t� optimis�e.");
const TCHAR tDeletingFailedBackup[]=_T("Suppression incompl�te ou sauvegarde echou�e.");

#if defined(WIN32) || defined(__LINUX__)
const TCHAR tEmailSendFailureXSctErrX[]=_T("�Chec de l'envoi de l'Email %u - Erreur 0x%X");
const TCHAR tEmailSentToX[]=_T("Email envoy� � %s");
#endif

const TCHAR tTargetPathCreated[]=_T("Le dossier cible a �t� cr��.");
const TCHAR tByteForByteFailureAtLBAXOffsetX[]=_T("�chec octet-par-octet au LBA %llu offset %u (%u)");

//-----------------
// progress
//-----------------
const TCHAR tToC[]=_T("Vers : ");
const TCHAR tBackupC[]=_T("Sauvegarde : ");
const TCHAR tRestoringC[]=_T("Restauration : ");
const TCHAR tValidatingC[]=_T("V�rification : ");
const TCHAR tCopyingC[]=_T("Copie : ");
const TCHAR tCopying[]=_T("Copie...");
const TCHAR tValidatingCopy[]=_T("V�rification de la copie...");
const TCHAR tFromC[]=_T("De : ");
const TCHAR tCurrentProcessC[]=_T("Traitement en cours : ") HIGHLIGHT;
const TCHAR tResizeCheckingddd[]=_T("Ajustement - V�rification syst�me...");
const TCHAR tResizingddd[]=_T("Ajustement...");
const TCHAR tResizeCheckingAgainddd[]=_T("Ajustement - Re-v�rification syst�me...");
const TCHAR tResizePhase1ddd[]=_T("Ajustement - Phase 1...");
const TCHAR tResizePhase2ddd[]=_T("Ajustement - Phase 2...");
const TCHAR tResizePhase3ddd[]=_T("Ajustement - Phase 3...");
const TCHAR tResizePhase4ddd[]=_T("Ajustement - Phase 4...");
const TCHAR tResizePhase5ddd[]=_T("Ajustement - Phase 5...");
const TCHAR tResizePhase6ddd[]=_T("Ajustement - Phase 6...");
const TCHAR tAnalyzing[]=_T("Analyse...");
const TCHAR tPleaseWait[]=_T("Merci de patienter...");
const TCHAR tProcessingItemUofU[]=_T("Traitement de l'�l�ment : %u sur %u");
const TCHAR tImagingInProcess[]=_T("Cr�ation de l'image...");
const TCHAR tRestoringImage[]=_T("Restauration de l'image...");
const TCHAR tCompletingRestore[]=_T("Finalisation de la restauration...");
const TCHAR tCompletingCopy[]=_T("Finalisation de la copie...");
const TCHAR tValidatingImage[]=_T("V�rification de l'image...");
const TCHAR tValidatingDisc[]=_T("V�rification du disque...");
const TCHAR tErasingCD[]=_T("Effacement du disque...");
const TCHAR tClosingCD[]=_T("Fermeture du disque...");
const TCHAR tAccessingCD[]=_T("Acc�s au disque...");
const TCHAR tSecond[]=_T("seconde");
const TCHAR tSeconds[]=_T("secondes");
const TCHAR tHour[]=_T("heure");
const TCHAR tHours[]=_T("heures");
const TCHAR tMinute[]=_T("minute");
const TCHAR tMinutes[]=_T("minutes");
const TCHAR tDayXHourXMinXSecX[]=_T("%01u:%02u:%02u:%02u");

const TCHAR tMBTransfered[]=_T("MiB transf�r�s :");
const TCHAR tMBRemaining[]=_T("MiB restants :");
const TCHAR tTimeElapsed[]=_T("Dur�e �coul�e :");
const TCHAR tTimeRemaining[]=_T("Dur�e restante :");

const TCHAR tOverallProgress[]=_T("Totale");
const TCHAR tStatistics[]=_T("Statistiques");

const TCHAR tLogStartEngineXX[]=_T("D�marrage de %s...") NEWLINE _T("%s");
const TCHAR tLogCompletionCodeX[]=_T("Op�ration termin�e avec le code erreur %u");
const TCHAR tLogSuccess[]=_T("Op�ration termin�e avec succ�s");
const TCHAR tLogStopEngine[]=_T("Arr�t");
const TCHAR tCLProgramExitCodeX[]=_T("Le programme s'est arr�t� avec le code erreur %u") NEWLINE;

//
// summary
//
const TCHAR tOperationC[]=_T("Op�ration : ");
const TCHAR tItemsToProcessC[]=_T("Nombre d'�l�ments : ");
const TCHAR tRawHDListed[]=_T(" - RAW");
const TCHAR tRawDrive[]=_T("Disque entier (brut)");

//------------------
// status bar text
//------------------
#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tStatusBarNorm[]=_T(" \aF12\a Quitter");
const TCHAR tStatusBarVorPDlgRSel[]=_T(" \aF1\a D�tails  \aF12\a Quitter");
const TCHAR tStatusBarFileDlg[]=_T(" \aF1\a Description  \aF12\a Quitter");
const TCHAR tStatusBarOptionsDlg[]=_T(" \aF4\a Enr. d�fauts  \aF12\a Quitter");
const TCHAR tStatusBarSummaryDlg[]=_T(" \aF6\a Voir commande  \aF8\a Enr. commande  \aF12\a Cancel");
const TCHAR tStatusBarVorPDlgR[]=_T(" \aIns\a Cr�er �tendue  \aDel\a Supprimer  \aF1\a D�tails  \aF6\a G�om�trie \aF12\a Quitter");
const TCHAR tStatusBarVorPDlgGeoOnly[]=_T(" \aF6\a G�om�trie  \aF12\a Quitter");
const TCHAR tStatusBarVorPDlgB[]=_T(" \aDel\a Supprimer  \aF1\a D�tails  \aF3\a Compacter  \aF12\a Quitter");
const TCHAR tStatusBarVirtDrivesDlg[]=_T(" \aF2\a Ajouter disque virtuel  \aF12\a Quitter");
const TCHAR tStatusBarGeoVirtDrivesDlg[]=_T(" \aF2\a Ajouter disque virtuel  \aF6\a G�om�trie  \aF12\a Quitter");
const TCHAR tStatusBarDrivesDlg[]=_T(" \aF6\a G�om�trie  \aF12\a Quitter");
const TCHAR tStatusBarSimpleSelTargetDevice[]=_T(" \aF10\a Select Target Device Manually  \aF12\a Cancel");
 #if !defined(RESTORE_ONLY)
const TCHAR tStatusBarDrivesDlgSimpleB[]=_T(" \aF3\a Compact  \aF12\a Cancel");
 #endif
#endif

#if defined(WIN32)
const TCHAR tPHYLockActive[]=_T("(PHYLock actif)");
const TCHAR tPHYLockUsingDisk[]=_T("(PHYLock avec disque)");
const TCHAR tPHYLockUsingRAM[]=_T("(PHYLock avec RAM)");
#endif

//------------------
// options
//------------------
#if defined(DOS_GUI) || defined(LINUX_GUI)
const TCHAR tHKOptions[]=_T("&Options");
#else
const TCHAR tOptions[]=_T("Options");
#endif
const TCHAR tNoDescription[]=_T("Pas de description.");
const TCHAR tDescription[]=_T("Description");
const TCHAR tHKDescription[]=_T("&Description");
const TCHAR tHKPassword[]=_T("&Mot de passe");
const TCHAR tDrive[]=_T("Lecteur");
const TCHAR tEntireDrive[]=_T("Lecteur complet");
const TCHAR tCommandLine[]=_T("Ligne de commande");

//------------------
// backup options
//------------------

#if !defined(RESTORE_ONLY)
const TCHAR tPasswordsDoNotMatch[]=_T("Les mots de passe ne sont pas identiques.");
const TCHAR tHKFileSize[]=_T("&Taille du fichier");
const TCHAR tFileSizeTooSmall[]=_T("La taille du fichier doit �tre d'au moins 256 KiB.");
const TCHAR tHKCompression[]=_T("&Compression");
#endif

#if !defined(RESTORE_ONLY)
sCGEmbedList AddtionalBackupOptsList[]={
                                   CGembedID,
  _T("&V�rifier"),                 IDclbValidate,
  _T("V�rifier &octet-par-octet"), IDclbValidateB,
  _T("&Crypter les donn�es"),     IDclbEncAES,
  _T("&Ignorer le fichier d'�change"),      IDclbOmitPageFile,
  _T("Ignorer le fichier d'&hibernation"),    IDclbOmitHiberFile,
  _T("Ignorer &erreurs d'entr�e/sortie"),         IDclbAllowErrorsB,
 #if defined(_WIN32)
  _T("&Read from Volume"),          IDclbUseVolumeIO,
 #endif
  _T("D�sactiver l'�&jection automatique"),       IDclbDisableEject,
  _T("&Red�marrer apr�s traitement"),    IDclbReboot,
  _T("�&teindre apr�s traitement"),  IDclbShutdown,
  _T("Enregistrer les tr&aces"),                 IDclbSaveLog,
  NULL };

sCGEmbedList AdditionalCombineOptsList[]={
                                 CGembedID,
  _T("&V�rifier"),                 IDclbValidate,
  _T("Delete &Combined Files"),  IDclbDelCombinedFiles,
  _T("&Crypter les donn�es"),     IDclbEncAES,
  _T("D�sactiver l'�&jection automatique"),       IDclbDisableEject,
  _T("&Red�marrer apr�s traitement"),    IDclbReboot,
  _T("�&teindre apr�s traitement"),  IDclbShutdown,
  _T("Enregistrer les tr&aces"),                 IDclbSaveLog,
  NULL };

sCGEmbedList CDAddtionalBackupOptsList[]={
  CGembedID,
  _T("V�rifier le &disque"),  IDclbDiscValidate,
  _T("&Limiter l'utilisation du disque"),  IDclbIgnoreDiscEdges,
  NULL };

sCGEmbedList FinalBackupOptsList[]={
  CGembedID,
    _T("Compati&bilit& descendante"),               IDclbOldFormat,
  NULL };

sCGEmbedList BackupUnusedSecsOptsList[]= {
  CGembedID,
  _T("&Sauvegarder secteurs inutilis�s"),    IDclbRaw,
  NULL };

sCGEmbedList CreateHashOptsList[]= {
  CGembedID,
  _T("&Faster Changes Only Backups"),     IDclbCreateHash,
  _T("Use &Metadata Hash Files"),   IDclbUseMetaData,
  NULL };

sCGEmbedList AdditionaDiffBackupOptsList[]= {
  CGembedID,
  _T("Delete Hash Files &Used"),         IDclbDelHashFiles,
  NULL };

#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tFileSizeSelection[]=_T("Max\0" "7.95 GiB\0" "4.37 GiB\0" "4 GiB\0" "2 GiB\0" "698 MiB\0" "648 MiB\0");
const TCHAR tCompressionOptsList[]=_T("Aucune\0" "Standard\0" "Taille optimis�e - A\0" "Taille optimis�e - B\0" "Taille optimis�e - C\0" "Taille optimis�e - D\0" "Taille optimis�e - E\0" "Taille optimis�e - F\0" "Vitesse optimis�e - A\0" "Vitesse optimis�e - B\0" );
#endif // !DOS_GUI || !LINUX_GUI

#endif // !restore only


const TCHAR tEnterFileNameForDisc[]=_T("Indiquer le nom de fichier");
const TCHAR tCDBackupDefaultName[]=_T("SVEGARD");
const TCHAR tErrCDFilenameIncludesPath[]=_T("Vous ne devez indiquer ni le lecteur ni le chemin.");
const TCHAR tErrFilenameExtension[]=_T("Vous ne devez pas indiquer l'extension.");

const TCHAR tNoCheckBoxesSelected[]=_T("Aucun �l�ment s�lectionn�.\nUtilisez la barre d'espace pour s�lectionner les �l�ments.");

//------------------
// copy options
//------------------
#if !defined(RESTORE_ONLY)

sCGEmbedList tAdditionalSPCopyOpts[]={
                                       CGembedID,
  _T("Marquer la partition &Active"),                 IDclbSetActive,
  _T("Modifier BOOT.&INI"),            IDclbUpdateBootIni,
  NULL
};

sCGEmbedList tAdditionalMVCopyOpts[]={
                                    CGembedID,
  _T("Modifier &partition de boot"),     IDclbUpdateBootPart,
  _T("�crire un code &MBR standard"),   IDclbWriteMBR,
  _T("Copier la si&gnature disque"),       IDclbDiskSig,
  _T("&Copier la premi�re piste"),          IDclbFirstTrack,
  _T("Modifier le &GUID"),       				IDclbChangeDiskSig,
  _T("V�rifier &octet-par-octet"),    IDclbValidateB,
  _T("Copier les secteurs &inutilis�s"),       IDclbRaw,
  _T("&Effacer les secteurs inutilis�s"), IDclbWipeData,
  _T("&Compact Data"),                  					 IDclbCompactData,
  _T("Ignorer le fichier d'&�change"),       IDclbOmitPageFile,
  _T("Ignorer le fichier d'&hibernation"),     IDclbOmitHiberFile,
  _T("D�placer � la &m�me entr�e MBR"),IDclbUseSameMBREntry,
  _T("GPT c&ach� de l'OS"),        IDclbOSIgnoresGPT,
  _T("Consid�rer le disque comme l'&original"),        IDclbLeaveBSHD,
  _T("Ignorer &erreurs d'entr�e/sortie"),          IDclbAllowErrors,
 #if defined(_WIN32)
  _T("&Read from Volume"),          IDclbUseVolumeIO,
 #endif
  _T("&Red�marrer apr�s traitement"),     IDclbReboot,
  _T("�&teindre apr�s traitement"),   IDclbShutdown,
  _T("Enregistrer les tr&aces"),       IDclbSaveLog,
  _T("Modifier ID des &volumes"),          IDclbChangeVolumeID,
  NULL };

sCGEmbedList tAdditionalFDCopyOpts[]={
                                       CGembedID,
  _T("Ajuster � la &taille"),               IDclbScaleToFit,
  _T("&Aligner selon la cible"),               IDclbAlignRestored,
  _T("Modifier le disque ID et les &GUIDs"),      IDclbChangeDiskSig,
  _T("V�rifier &octet-par-octet"),     IDclbValidateB,
  _T("�crire un code &MBR Standard"),    IDclbWriteMBR,
  _T("Copier les secteurs &inutilis�s"),        IDclbRaw,
  _T("&Effacer les secteurs inutilis�s"), IDclbWipeData,
  _T("Ignorer le fichier d'&�change"),        IDclbOmitPageFile,
  _T("Ignorer le fichier d'&hibernation"),      IDclbOmitHiberFile,
  _T("Supprimer �&carts en copiant"),        IDclbRemoveGaps,
  _T("GPT c&ach� de l'OS"),        IDclbOSIgnoresGPT,
  _T("&Compact Data"),                  					 IDclbCompactData,
  _T("Consid�rer disque comme &original"),         IDclbLeaveBSHD,
  _T("&Ajuster selon la cible"),            IDclbScaleToTarget,
  _T("&Ignorer erreurs d'entr�e/sortie"),           IDclbAllowErrors,
 #if defined(_WIN32)
  _T("&Read from Volume"),          IDclbUseVolumeIO,
 #endif
  _T("&Red�marrer apr�s traitement"),      IDclbReboot,
  _T("�&teindre apr�s traitement"),    IDclbShutdown,
  _T("Enregistrer les tr&aces"),        IDclbSaveLog,
  _T("Modifier ID des &volumes"),          IDclbChangeVolumeID,
  NULL };

#endif

//------------------
// restore options
//------------------
sCGEmbedList tUpdateBootPartitionOpt[]={
                                       CGembedID,
  _T("Mette � jour la &partition de boot"),      IDclbUpdateBootPart,
  NULL
};

sCGEmbedList tAddtionalSPRestoreOpts[]={
                                       CGembedID,
  _T("Marquer la partition &Active"),   IDclbSetActive,
  _T("Modifier BOOT.&INI"),              IDclbUpdateBootIni,
  NULL
};

sCGEmbedList tAddtionalMVRestoreOpts[]={
                                       CGembedID,
  _T("Mette � jour la &partition de boot"),      IDclbUpdateBootPart,
  _T("�crire un code &MBR standard"),    IDclbWriteMBR,
  _T("Restaurer la &signature disque"),     IDclbDiskSig,
  _T("&Restaurer la premiere piste"),        IDclbFirstTrack,
  _T("&V�rifier image avant restauration"),    IDclbPreValidate,
  _T("Modifier le &GUID"),       				IDclbChangeDiskSig,
  _T("V�rifier &octet-par-octet"), IDclbValidateB,
  _T("&Effacer les secteurs inutilis�s"), IDclbWipeData,
  _T("&Compact Data"),                  					 IDclbCompactData,
  _T("Utiliser la &m�me entr�e MBR"), IDclbUseSameMBREntry,
  _T("GPT c&ach� de l'OS"),        IDclbOSIgnoresGPT,
  _T("Consid�rer disque comme &original"),         IDclbLeaveBSHD,
  _T("&Ignorer erreurs d'entr�e/sortie"),           IDclbAllowErrors,
  _T("D�sactiver l'�&jection automatique"),         IDclbDisableEject,
  _T("&Red�marrer apr�s traitement"),      IDclbReboot,
  _T("�&teindre apr�s traitement"),    IDclbShutdown,
  _T("Enregistrer les tr&aces"),                   IDclbSaveLog,
  _T("Modifier ID des &volumes"),          IDclbChangeVolumeID,
  NULL
};


sCGEmbedList tAddtionalFDRestoreOpts[]={
                                       CGembedID,
  _T("Ajuster � la &taille"),               IDclbScaleToFit,
  _T("Ali&gner sur le disque"),            IDclbAlignRestored,
  _T("Modifier le disk ID et les &GUIDs"),      IDclbChangeDiskSig,
  _T("&V�rifier image avant restauration"),    IDclbPreValidate,
  _T("V�rification &octet-par-octet"), IDclbValidateB,
  _T("�crire un code &MBR standard"),    IDclbWriteMBR,
  _T("&Effacer les secteurs inutilis�s"), IDclbWipeData,
  _T("Supprimer �&carts en restaurant"),     IDclbRemoveGaps,
  _T("GPT c&ach� de l'OS"),        IDclbOSIgnoresGPT,
  _T("&Compact Data"),                  					 IDclbCompactData,
  _T("Consid�rer disque comme &original"),         IDclbLeaveBSHD,
  _T("&Ajuster selon la cible"),            IDclbScaleToTarget,
  _T("&Ignorer erreurs d'entr�e/sortie"),           IDclbAllowErrors,
  _T("D�sactiver l'�&jection automatique"),         IDclbDisableEject,
  _T("&Red�marrer apr�s traitement"),      IDclbReboot,
  _T("�&teindre apr�s traitement"),    IDclbShutdown,
  _T("Enregistrer les tr&aces"),                   IDclbSaveLog,
  _T("Modifier ID des &volumes"),          IDclbChangeVolumeID,
  NULL };

sCGEmbedList tWriteChangesOnlyOpt[]={
                                       CGembedID,
  _T("&Uniquement les secteurs modifi�s"), IDclbWriteChangesOnly,
  NULL };

sCGEmbedList tUseMetaDataOnRestore[]={
                                    CGembedID,
  _T("&Metadata Based Restore"),    IDclbUseMetaData,
  NULL };

const TCHAR tGeoOverride[]=_T("Ignorer la g�om�trie");
#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tCHSInvalid[]=_T("Les valeurs entr�es pour la g�om�trie CHS sont incorrectes.") NEWLINE
                          _T("Les valeurs maximales sont : C:1023, H:255, S:63.");
#endif
const TCHAR tCBUseOrgGeo[]=_T("Utiliser la g�om�trie &origine");
const TCHAR tCBUseMBRGeo[]=_T("Utiliser la g�om�trie &MBR");
const TCHAR tCB2048SectorAlign[]=_T("Aligner sur &1MiB");
const TCHAR tCBForceHSValues[]=_T("Aligner sur la &fin du MBR HS");
const TCHAR tCBForceHSOnTrunc[]=_T("Aligner sur MBR HS si &coupure");
const TCHAR tCBAlignOnEnd[]=_T("&Aligner sur la fin");
const TCHAR tCBAlignOnEndResize[]=_T("Aligner sur fin en ajustant &taille");
const TCHAR tHKSave[]=_T("&Sauver");
const TCHAR tCBUseGlobalSettings[]=_T("&Utiliser les param�tres g�n�raux");

const TCHAR tGlobalSettings[]=_T("Param�tres g�n�raux");
const TCHAR tGlobalGeometry[]=_T("G�om�trie");
const TCHAR tCBGlobalGeoDisable[]=_T("&D�sactiv�e");
const TCHAR tCBGlobalGeoAlignMBRHS[]=_T("Aligner MBR pour le mode &BIOS Auto");
const TCHAR tCBGlobalGeoAlign2K[]=_T("Aligner � &2KiB");
const TCHAR tCBGlobalGeoUseMBRGeo[]=_T("Consid�rer m�me &syst�me cible");
const TCHAR tCBGlobalGeoUseOrgGeo[]=_T("Utiliser la &g�om�trie source");
const TCHAR tCBUseWin7MBR[]=_T("Utiliser nouveau &format de MBR");
const TCHAR tOtherSettings[]=_T("Param�tres divers");
const TCHAR tCBGlobalGeoMBRGeoValidate[]=_T("&Valider g�om�trie avant utilisation");
const TCHAR tCBValidMBRGeoOnly[]=_T("&Valider g�om�trie du MBR");

const TCHAR tIncompleteImageInFileX[]=_T("Le fichier image %s n'est pas complet.");
const TCHAR tFirstTrackSectors[]=_T("Premi�re piste");
const TCHAR tInvalidFirstTrackSectors[]=_T("Nombre de secteurs incorrect pour restaurer la premiere piste.");
const TCHAR tHDx[]=_T("Disque dur &%i");
const TCHAR tEMBR[]=_T("EMBR");
const TCHAR tPasswordRequired[]=_T("Mot de passe requis");
const TCHAR tInvalidPassword[]=_T("Mot de passe incorrect");
const TCHAR tFileSelectIsNotTheBaseImage[]=_T("Le fichier s�lectionn� ne contient pas la sauvegarde de base.");
const TCHAR tInvalidResizeEntry[]=_T("Taille saisie incorrecte...") NEWLINE;
const TCHAR tResizeAfterRestore[]=_T("&Taille apr�s restauration");
const TCHAR tMin[]=HIGHLIGHT _T("Min") HIGHLIGHT;
const TCHAR tNew[]=HIGHLIGHT _T("Nvx") HIGHLIGHT;
const TCHAR tMax[]=HIGHLIGHT _T("Max") HIGHLIGHT;

const TCHAR tInvalidSizeEntry[]=_T("La taille saisie n'est pas valide.");
const TCHAR tFileDoesNotExistCreate[]=_T("Le fichier n'existe pas.") NEWLINE _T("Voulez-vous le cr�er ?");
const TCHAR tDeviceAllocatedCantRemove[]=_T("Le lecteur est d�j� allou� et ne peut pas �tre supprim�.");
#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tVirtDrvXX[]=_T("V%u - %s");
#endif
const TCHAR tNewVirtDrive[]=_T("Nouveau Disque Virtuel");
const TCHAR tName[]=_T("Nom");
const TCHAR tSize[]=_T("Taille");
const TCHAR tType[]=_T("Type");

sCGEmbedList tVirtDriveTypeList[]={
                                        CGembedID,
  _T("RAW  - Taille Fixe"),              VDEVCRT_RAW,
  _T("VHD  - Extensible"),       VDEVCRT_VPCSPARSE,
  _T("VHD  - Taille Fixe"),              VDEVCRT_VPCFIXED,
  _T("VHDX - Dynamic Expanding"),       VDEVCRT_VHDXSPARSE,
  _T("VHDX - Fixed Size"),              VDEVCRT_VHDXFIXED,
  _T("VHDX - Dynamic 4KiB Sectors"),    VDEVCRT_VHDXSPARSE4,
  _T("VHDX - Fixed Size 4KiB Sectors"), VDEVCRT_VHDXFIXED4,
  _T("VMDK - Monolithic Sparse (IDE)"), VDEVCRT_VMDKSPARSE,
  _T("VMDK - Monolithic Sparse (SCSI)"),VDEVCRT_VMDKSPARSESCSI,
  NULL };

//-------------------
// validate options
//-------------------
sCGEmbedList tAddtionalValidateOpts[]={
                                     CGembedID,
  _T("D�sactiver l'�&jection automatique"),         IDclbDisableEject,
  _T("Enregistrer les tr&aces"),                   IDclbSaveLog,
  NULL };


//-------------------
// menu sub titles
//-------------------
const TCHAR tSelectDriveForFile[]=_T("S�lectionnez le lecteur du fichier");
const TCHAR tSelectSourceDrive[]=_T("S�lectionnez le lecteur souce");
const TCHAR tSelectTargetDrive[]=_T("S�lectionnez le lecteur cible");

//const TCHAR tAllItemsWillBeDeletedHDx[]=_T("Partitions de HD%u qui seront supprim�es.");
const TCHAR tConfirmSelectedHDx[]=_T("Confirmation du disque HD%u s�lectionn�.");
const TCHAR tSelectItemToProcess[]=_T("S�lectionnez l'�l�ment � traiter");
#if !defined(RESTORE_ONLY)
const TCHAR tSelectItemToBackupHDx[]=_T("S�lectionnez l'�l�ment � sauvegarder du disque HD%u");
#endif
const TCHAR tSelectItemToRestoreHDx[]=_T("S�lectionnez l'�l�ment cible sur disque HD%u");
const TCHAR tSelectItemForFileHDx[]=_T("S�lectionnez le chemin sur le disque HD%u");

#if !defined(RESTORE_ONLY)
const TCHAR tSelectItemToCopyHDx[]=_T("S�lectionnez les �l�ments � copier de HD%u");
#endif

const TCHAR tSelectBaseBackup[]=_T("S�lectionnez le prochain fichier de sauvegarde");

const TCHAR tSelectDriveInterface[]=_T("S�lectionnez le mode d'interface du lecteur");
const TCHAR tSelectFileAccessMethod[]=_T("S�lectionnez le mode d'acc�s au fichier");
const TCHAR tSelectOperation[]=_T("S�lectionnez l'op�ration");

const TCHAR tSelect[]=_T("S�lectionnez");
const TCHAR tDelete[]=_T("Supprimez");

#if !defined(RESTORE_ONLY)
const TCHAR tSelectBaseForBackup[]=_T("S�lectionnez le fichier de sauvegarde");
const TCHAR tFilesInListWillBeDeleted[]=_T("Liste des fichiers qui seront supprim�s");
const TCHAR tOkayToDeleteItemList[]=_T("�tes-vous s�r de vouloir continuer ?");
const TCHAR tDoYouWantToDeleteTheFiles[]=_T("Voulez-vous supprimer le(s) fichier(s) list�(s) ci-dessus ?");
#endif

const TCHAR tPromptHDLoadProblem[]=_T("Une erreur de lecture est survenue lors de l'acc�s au lecteur.\n");
const TCHAR tPromptPartProblem[]=_T("La liste des partitions contient des erreurs.\n");

//----------------
// menu buttons
//----------------
#if defined(DOS_GUI) || defined(LINUX_GUI)
const TCHAR tHKBack[]=_T("<< Retour");
const TCHAR tHKNext[]=_T("Suivant >>");
#else
const TCHAR tHKBack[]=_T("&Retour");
const TCHAR tHKNext[]=_T("&Suivant");
#endif
const TCHAR tHKFinish[]=_T("&D�marrer");

//--------------
// menu titles
//--------------
#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tMainMenu[]=_T("Menu principal");
#endif
const TCHAR tRestore[]=_T("Restaurer");
const TCHAR tValidate[]=_T("V�rifier");
const TCHAR tRestoreTo[]=_T("Restaurer vers");
const TCHAR tRestoreFrom[]=_T("Restaurer depuis");
const TCHAR tSummary[]=_T("R�sum�");
#if !defined(RESTORE_ONLY)
const TCHAR tBackup[]=_T("Sauvegarder");
const TCHAR tBackupFrom[]=_T("Sauvegarder depuis");
const TCHAR tBackupTo[]=_T("Sauvegarder vers");
const TCHAR tHKWriteSpeed[]=_T("&Vitesse d'�criture");
#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tCopy[]=_T("Copie");
#endif
const TCHAR tCopyFrom[]=_T("Copie de");
const TCHAR tCopyTo[]=_T("Copie vers");
#endif


//--------------
// menu lists
//--------------
#if defined(DOS_GUI) || defined(LINUX_GUI)
 #if defined(RESTORE_ONLY)
  sFGEmbedList tBackupRestoreValidateMenu[]={
      OPidRestore,   0, _T("&Restaurer"),
      OPidValidate,  0, _T("&Valider"),
      0, 0, NULL };

  sFGEmbedList tSimpleBackupRestoreValidateMenu[]={
      OPidRestore,   0, _T("&Restaurer"),
      OPidValidate,  0, _T("&Valider"),
      0, 0, NULL };
 #else
  sFGEmbedList tBackupRestoreValidateMenu[]={
      OPidBackup,    0, _T("&Sauvegarder"),
      OPidRestore,   0, _T("&Restaurer"),
      OPidValidate,  0, _T("&Valider"),
      OPidCopy,      0, _T("&Copier"),
      0, 0, NULL };

  sFGEmbedList tSimpleBackupRestoreValidateMenu[]={
      OPidBackup,    0, _T("&Sauvegarder"),
      OPidRestore,   0, _T("&Restaurer"),
      OPidValidate,  0, _T("&Valider"),
      OPidCopy,      0, _T("&Copier"),
      0, 0, NULL };

  sFGEmbedList tSingleMultiFileMenu[]={
      MFidSingle,    0, _T("Jeu de Fichier &Unique"),
      MFidMulti,     0, _T("Jeu de Fichiers &Multiple"),
      0, 0, NULL };

  sFGEmbedList tFullDifferentialMenu[]={
      FDidFull,      0, _T("Sauvegarde &Compl�te"),
      FDidDiff,      0, _T("&Modifications Seules"),
      FDidCombine,   0, _T("Co&mbine Files"),
      0, 0, NULL };

  sFGEmbedList tSpeedSelection[]={
      SPEEDidOpt,    0, _T("Optimal"),
      SPEEDid4x,     0, _T("4X"),
      SPEEDid8x,     0, _T("8X  - 1X DVD"),
      SPEEDid12x,    0, _T("12X"),
      SPEEDid16x,    0, _T("16X - 2X DVD"),
      SPEEDid24x,    0, _T("24X"),
      SPEEDid32x,    0, _T("32X - 4X DVD"),
      0, 0, NULL };

  sFGEmbedList tFileSizeSelection[]={
      0,        0, _T("Max"),
      0,        0, _T("7.95GiB"),
      0,        0, _T("4.37GiB"),
      0,        0, _T("4GiB"),
      0,        0, _T("2GiB"),
      0,        0, _T("698MiB"),
      0,        0, _T("648MiB"),
      0, 0, NULL };

  sFGEmbedList tCompressionOptsList[]={
      COMPidNone,    0, _T("Aucune"),
      COMPidStandard,0, _T("Standard"),
      COMPidEnhBest, 0, _T("Taille optimis�e - A"),
      COMPidEnhSlr,  0, _T("Taille optimis�e - B"),
      COMPidEnhSwt,  0, _T("Taille optimis�e - C"),
      COMPidEnhSizeA,0, _T("Taille optimis�e - D"),
      COMPidEnhSizeB,0, _T("Taille optimis�e - E"),
      COMPidEnhSizeC,0, _T("Taille optimis�e - F"),
      COMPidEnhFastA,0, _T("Vitesse optimis�e - A"),
      COMPidEnhFastB,0, _T("Vitesse optimis�e - B"),
      0, 0, NULL };

 #endif

  sFGEmbedList tSingleMultiPassMenu[]={
      MPidSingle,    0, _T("Passage &Simple"),
      MPidMulti,     0, _T("Passage &Multiple"),
      0 , 0, NULL };

  sFGEmbedList tRestoreAutoManualMenu[]={
      RESTidAuto,    0, _T("&Automatique"),
      RESTidNormal,  0, _T("&Normal"),
      0, 0, NULL };

 #if !defined(__LINUX__)
  sFGEmbedList tBIOSATAUSB1394[]={
      BUSidBIOS,     0, _T("&BIOS"),
      BUSidBIOSD,    0, _T("BIOS (&Direct)"),
      BUSidUSB,      0, _T("&USB"),
      BUSid1394,     0, _T("&IEEE1394"),
      BUSidVirtual,  0, _T("Disque &Virtuel"),
      0, 0, NULL };
 #else
  sFGEmbedList tLinuxVirtual[]={
      BUSidOS,       0, _T("&Linux"),
      BUSidVirtual,  0, _T("Disque &Virtuel"),
      0, 0, NULL };

  sFGEmbedList tAtapiSG[]={
      CDBUSidAtapi,    0, _T("&ATAPI/SCSI"),
      CDBUSidSG,       0, _T("&SG"),
      0, 0, NULL };

 const TCHAR tNoCDExcl[]=_T("Impossible d'�tablir un acc�s exclusif au lecteur CD/DVD.");
 #endif

  sFGEmbedList tFileDirectOSCD[]={
      FILEidDirect,  0, _T("Fichier (&Direct)"),
      FILEidOS,      0, _T("Fichier (&OS)"),
      FILEidCD,      0, _T("Fichier (&CD/DVD)"),
      0, 0, NULL };

 #if !defined(LINUX_GUI)

  sFGEmbedList tFileDirectCD[]={
      FILEidDirect,  0, _T("Fichier (&Direct)"),
      FILEidCD,      0, _T("Fichier (&CD/DVD)"),
      0, 0, NULL };

  sFGEmbedList tAtapiASPIUSB1394[]={
      CDBUSidATAPI,  0, _T("&ATAPI"),
      CDBUSidASPI,   0, _T("A&SPI"),
      CDBUSidUSB,    0, _T("&USB2"),
      CDBUSid1394,   0, _T("&IEEE1394"),
      0, 0, NULL };
 #endif

#else // !DOS_GUI && !LINUX_GUI
 #if defined(RESTORE_ONLY)
  #if defined(__LINUX__)
    const TCHAR tBackupRestoreValidateMenu[]=_T("&Restaurer\0&V�rifier\0&Param�tres g�n�raux\0&D�tecter nouveaux lecteurs\0&Quitter\0");
    const TCHAR tSimpleBackupRestoreValidateMenu[]=_T("&Restaurer\0&V�rifier\0&Param�tres g�n�raux\0&D�tecter nouveaux lecteurs\0&Quitter\0");
  #else
    const TCHAR tBackupRestoreValidateMenu[]=_T("&Restaurer\0&V�rifier\0&Param�tres g�n�raux\0&Quitter\0");
    const TCHAR tSimpleBackupRestoreValidateMenu[]=_T("&Restaurer\0&V�rifier\0&Param�tres g�n�raux\0&Quitter\0");
  #endif
 #else  // !RESTORE_ONLY
  #if defined(WIN32)
  const TCHAR tBackupRestoreValidateMenu[]=_T("&Sauvegarder\0&Restaurer\0&V�rifier\0&Copier\0&Param�tres g�n�raux\0&Options PHYLock\0&Quitter\0");
  const TCHAR tSimpleBackupRestoreValidateMenu[]=_T("&Sauvegarder\0&Restaurer\0&V�rifier\0&Copier\0&Param�tres g�n�raux\0&Options PHYLock\0&Quitter\0");
  #elif defined(__LINUX__)
  const TCHAR tBackupRestoreValidateMenu[]=_T("&Sauvegarder\0&Restaurer\0&V�rifier\0&Copier\0&Param�tres g�n�raux\0&D�tecter nouveaux lecteurs\0&Quitter\0");
  const TCHAR tSimpleBackupRestoreValidateMenu[]=_T("&Sauvegarder\0&Restaurer\0&V�rifier\0&Copier\0&Param�tres g�n�raux\0&D�tecter nouveaux lecteurs\0&Quitter\0");
  #else
  const TCHAR tBackupRestoreValidateMenu[]=_T("&Sauvegarder\0&Restaurer\0&V�rifier\0&Copier\0&Param�tres g�n�raux\0&Quitter\0");
  const TCHAR tSimpleBackupRestoreValidateMenu[]=_T("&Sauvegarder\0&Restaurer\0&V�rifier\0&Copier\0&Param�tres g�n�raux\0&Quitter\0");
  #endif
const TCHAR tSingleMultiFileMenu[]=_T("&DLot de fichiers uniques\0&Lot de fichiers multiple\0");
const TCHAR tFullDifferentialMenu[]=_T("&Sauvegarde compl�te\0&Modifications seules\0Co&mbine\0");
const TCHAR tSpeedSelection[]=_T("Optimal\0" "4X\0" "8X  - 1X DVD\0" "12X\0" "16X - 2X DVD\0" "24X\0" "32X - 4X DVD\0");
 #endif // !RESTORE_ONLY

const TCHAR tSingleMultiPassMenu[]=_T("&Passage unique\0Passage &multi\0");
const TCHAR tRestoreAutoManualMenu[]=_T("&Automatique\0&Normal\0");

 #if defined(WIN32)
  const TCHAR tBIOSATAUSB1394[]=_T("Lecteur &Windows\0Lecteur &Virtuel\0");
 #elif defined(__LINUX__)
  const TCHAR tBIOSATAUSB1394[]=_T("Lecteur &Linux\0Lecteur &Virtuel\0");
 #else
  const TCHAR tBIOSATAUSB1394[]=_T("&BIOS\0BIOS (&Direct)\0&USB\0&IEEE1394\0Lecteur &virtuel\0");
 #endif

const TCHAR tFileDirectOSCD[]=_T("Fichier (&Direct)\0Fichier (&OS)\0Fichier (&CD/DVD)\0");

 #ifndef __LINUX__
const TCHAR tFileDirectCD[]=_T("Fichier (&Direct)\0Fichier (&CD/DVD)\0");
const TCHAR tAtapiASPIUSB1394[]=_T("&ATAPI\0A&SPI\0&USB2\0&IEEE1394\0");
 #endif
 #ifdef __LINUX__
const TCHAR tAtapiSG[]=_T(" &ATAPI/SCSI\0 &SG\0");
const TCHAR tNoCDExcl[]=_T("Impossible d'�tablir un acc�s exclusif au lecteur CD/DVD.");
 #endif

#endif // !DOS_GUI

//---------------
// FileDlg Text
//---------------
const TCHAR tOpen[] = _T("Ouvrir");
const TCHAR tSaveAs[] = _T("Enregistrer sous");
const TCHAR tHKYes[] = _T("&Oui");
const TCHAR tHKNo[] = _T("&Non");

#if defined(LINUX_GUI)
  // n�ed to separater or yeilds \xCA instead of \x1B
  const char tHKCancel[]="\x1B" "Annuler";
  const char tHKOK[]="\x0AOK";
#else
  const TCHAR tHKOK[] = _T("&OK");
  const TCHAR tHKCancel[] = _T("&Annuler");
#endif

#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tHKRetry[] = _T("&R�essayer");
const TCHAR tHKIgnore[] = _T("&Ignorer");
const TCHAR tHKAll[] = _T("&Tous");
const TCHAR tHKNone[] = _T("&Aucun");
const TCHAR tHKFiles[] = _T("&Fichiers :");
const TCHAR tAccessDenied[] = _T("Acc�s non autoris�.");
const TCHAR tCreateFolder[] = _T("Cr�er dossier");
const TCHAR tEnterFolderName[] = _T("Entrez le nom du dossier :");
const TCHAR tFolderNotFoundCreateIt[] = _T("Dossier non trouv�. Voulez-vous le cr�er ?");
const TCHAR tHKFolders[] = _T("&Dossiers:");
const TCHAR tFolderCreationFailed[] = _T("Impossible de cr�er le dossier.");
#endif
const TCHAR tCannotOpenS[] = _T("Impossible d'ouvrir \"%s\".");

const TCHAR t3Dots[] = _T("...");

const TCHAR tLTDirGT[]=_T("<DIR>     ");
const TCHAR tHKName[] = _T("&Nom :");

const TCHAR tError[] = _T("Erreur");
const TCHAR tFileNotFound[] = _T("Fichier non trouv�.");
const TCHAR tFileAlreadyExists[] = _T("Le fichier existe d�j�");
const TCHAR tOverwriteS[] = _T("�crire sur \"%s\" ?");
const TCHAR tInvalidExtension[] = _T("Extension de fichier incorrecte");
const TCHAR tCGFDInvalidPath[] = _T("Chemin incorrect au format DOS 8.3");
const TCHAR tWarning[]= _T("Attention");

const TCHAR tSelectFolder[] = _T("S�lectionnez dossier");

//---------------------
// PHYLock
//---------------------
const TCHAR tDeleteFileX[]=_T("Supprimer %s ?");
#if defined(WIN32)
const TCHAR tAreYouSureNoLock[]=_T("Pour cr�er une image propre sous Windows,\n"
                                   "le volume doit �tre verouill�.\n\n"
                                   "�tes-vous s�r de vouloir continuer sans verrouillage ?");
const TCHAR tUnableToLockXX[]=_T("Impossible de verrouiller le lecteur %s %s");
const TCHAR tConsiderPHYLock[]=_T("\n\nVous pouvez utiliser le module gratuit PHYLock\n"
                                  "t�l�chargeable sur www.terabyteunlimited.com");

const TCHAR tPHYLockCantStartOnX[]=_T("Impossible de lancer PHYLock pour le lecteur %s\n"
                                      "Essayez de r�duire la taille du cache.");

const TCHAR tPHYLockStarting[]=_T("D�marrage de PHYLock...");

const TCHAR tLockingVolumes[]=_T("En attente de Windows...");

const TCHAR tOSRAIDWarning[]=_T("ATTENTION : le syst�me semble utiliser un syst�me RAID\n"
                                "qui n'a pas �t� virtualis� par le syst�me d'exploitation.\n"
                                "N'utilisez pas ce programme pour sauvegarder ou restaurer\n"
                                "un volume ou un lecteur dynamique.");

const TCHAR tPHYLockVersionX[]=_T("PHYLock version %u");

const TCHAR tIgnoringLock[]=_T("Verrouillage ignor�");
const TCHAR tPHYLockStarted[]=_T("PHYLock d�marr�");
const TCHAR tPHYLockNotStarted[]=_T("PHYLock n'a pas reussi a d�marrer.");

const TCHAR tValueEnteredInvalid[]=_T("La valeur entr�e est incorrecte\n");

const TCHAR tPHYLock[]=_T("PHYLock");
const TCHAR tPHYLockOptions[]=_T("Options PHYLock");
const TCHAR tMemory[]=_T("M�moire");
const TCHAR tHKMore[]=_T("&Plus");
const TCHAR tHKNormal[]=_T("&Normal");
const TCHAR tHKLess[]=_T("&Moins");
const TCHAR tHKDiskCacheSize[]=_T("Taille du cache &disque (MiB)");
const TCHAR tHKWriteFreeTime[]=_T("�crire le &temps d'attente (ms)");
const TCHAR tHKMaxWaitTime[]=_T("Temps d'attente ma&ximal (minutes)");
const TCHAR tHKCacheSize[]=_T("Taille du cache &RAM (Kio)");

const TCHAR tPHYLockDiskCacheDriveX[]="PHYLock utilise le lecteur %c:";

const TCHAR tPHYLockVersionXUnsupported[]="Version de PHYLock %u non support�e";

sCGEmbedList PHYLockOptsList[]={
                                CGembedID,
  _T("&D�sactiver l'utilisation"),         IDclbPLDisable,
  _T("&Utiliser si le verrouillage �choue"),  IDclbPLNoLock,
  _T("Utiliser apr�s le verrouillage par l'&OS"),  IDclbPLAfterLock,
  _T("&Flusher le volume"),          IDclbPLVolFlush,
  _T("Utiliser le &stockage sur disque"),      IDclbPLUseDisk,
  _T("Utiliser &VSS si possible"),IDclbPLUseVSS,
  _T("VSS: &Exclure les fichiers � ne pas sauvegarder"),IDclbPLUseFTNB,
  _T("VSS: Exclure les fichiers du Sna&pshot"),IDclbPLUseFTNS,
  _T("VSS: &Lock Unsupported Volumes"), IDclbPLVSSLUV,
  _T("VSS: &Ignore Unsupported Volumes"), IDclbPLVSSIUV,
  _T("VSS: Use &Component Mode"), IDclbPLVSSCM,
  _T("VSS: Use if &Locking Fails"), IDclbPLVSSINL,
  _T("VSS: Use VSS for Simple &Operations"), IDclbPLVSSFSM,
  NULL };

const TCHAR tAttemptingToCreateVSSSnapshot[]=_T("Tentative de cr�ation d'un clich� VSS...");
const TCHAR tSnapShotFailedErrX[]=_T("�chec de la cr�ation du clich� VSS (%Xh)");
const TCHAR tSnapShotCreated[]=_T("Clich� VSS cr�� avec succ�s.");
const TCHAR tUsingVSS[]=_T("Utilisation du service de clich� instantan� des volumes");
const TCHAR tStoppingVSS[]=_T("Fermeture du service de clich� instantan� des volumes...");
const TCHAR tNotifyVSSBackupCompleted[]=_T("Notification au VSS de la fin de la sauvegarde...");
const TCHAR tAddedVolumeSStoSnapshot[]=_T("Ajout de %s%s au clich�.");
const TCHAR tAddingVolumeSSToSnapshot[]=_T("Ajout de %s%s au clich�.");
const TCHAR tUnableToLockSS[]=_T("Impossible de verrouiller le lecteur %s%s");

const TCHAR tSkippingLockOnDriveX[]=_T("Verrouillage du lecteur %c ignor� :");
const TCHAR tIgnoringFailedLockOnDriveX[]=_T("�checs de verrouillage du lecteur %c ignor�s :");

//---------------------------
// Service logging
//---------------------------
const TCHAR tServiceLog[]="SC(%u): %s %s %s";
const TCHAR tStop[]="Arr�ter";
const TCHAR tSvcContinue[]="Continuer";
const TCHAR tPause[]="Pause";
const TCHAR tStart[]="D�marrer";
const TCHAR tUnknownRequest[]="Demande inconnue";
const TCHAR tBeforeBackup[]="Avant sauvegarde";
const TCHAR tAfterBackup[]="Apres sauvegarde";
const TCHAR tBeforePHYLockStart[]="Avant d�marrage de PHYLock";
const TCHAR tAfterPHYLockStart[]="Apr�s d�marrage de PHYLock";

#endif

//---------------------
// evaluation messages
//---------------------
#ifdef EVALUATION
const TCHAR tEvaluation1[]=_T("Ce programme est une version d'essai. Il ne peut �tre utilis� que pour evaluation.");
const TCHAR tEvaluation2[]=_T("Pour acquerir une licence compl�te, visitez www.terabyteinc.com");
#else
const TCHAR tWrongCDBootF35Version[]=_T("Le fichier CDBOOT.F35 appartient a la version d'essai\n") NEWLINE
                                     _T("et ne doit pas �tre utilis�.");

#if defined(__LINUX__)
const TCHAR tEnterProductKeyInformation[]=_T("Entrez la cl� de licence de Image For Linux inscrite sur le bulletin d'inscription.");
#elif defined(_WIN32)
const TCHAR tEnterProductKeyInformation[]=_T("Entrez la cl� de licence de Image For Windows inscrite sur le bulletin d'inscription.");
#elif defined(__MSDOS__)
const TCHAR tEnterProductKeyInformation[]=_T("Entrez la cl� de licence de Image For DOS (en laissant le nom vide) - ou le nom et la cl� de produit de BootIt Bare Metal - inscrite sur le bulletin d'inscription.");
#endif

const TCHAR tKey[]=_T("Cl�");
 #if defined(DOS_GUI) || defined(LINUX_GUI)
const TCHAR tHKKey[]=_T("&Cl�");
 #endif


#endif

#if defined(EVALUATION) //|| defined(_WIN32)

const TCHAR tEvaluationExpired[]=_T("La p�riode d'evaluation est termin�e. Pour commander la version") NEWLINE
                                 _T("compl�te de IMAGE, visitez www.terabyteunlimited.com.");
#else

const TCHAR tKeyExpired[]=_T("Votre licence est termin�e. Merci d'acquerir une") NEWLINE
                          _T("nouvelle cl� en renouvellent votre inscription.");

#endif


#if !defined(EVALUATION)
const TCHAR tEnterSerialNumber[]=_T("Entrez la cl� du produit");
const TCHAR tInvalidKey[]=_T("Cl� invalide");
#endif

const TCHAR tWriteErrorLBAX[]=_T("Erreur d'�criture disque au LBA %llu");
const TCHAR tReadErrorLBAX[]=_T("Erreur de lecture disque au LBA %llu");
const TCHAR tEMBRMismatch[]=_T("EMBR (non-syncro!)");
const TCHAR tNoSourcePartitionsAvailable[]=_T("Aucune partition source trouv�e.\n(seul mode brut - disque complet, secteurs inutilis�s - autoris�)");
const TCHAR tErrorXFileXDetailsBxFPxBRxECx[]="Erreur %s %s (Tampon:%p CurFP:%llu Octets:%u Err:%Xh)";

const TCHAR tFirstTrackSectorsLocked[]=_T("La cr�ation de la sauvegarde n�cessite que les options suivantes soient desactiv�es:") NEWLINE
                                       _T("  [/t]   �crire un code MBR standard") NEWLINE
                                       _T("  [/rft] Restaurer premi�re piste");

const char tCancel[]="Annuler";

#if defined(DOS_GUI) || defined(LINUX_GUI)
const char tSelTarDrvManually[]=_T("&Select Target Drive Manually");
const char tHKContinue[]="&Continue";
//const char tHKRollback[]="\177Rollback";
//const char tHKYes[]="\177Yes";
//const char tHKNo[]="\177No";

#if defined(__LINUX__)
extern const TCHAR tYes[]=_T("Oui");
extern const TCHAR tNo[]=_T("Non");
const char tHKNameCOLON[] = "&Nom:";
#else
const char tHKNameCOLON[] = "&Nom:";
#endif

const char tOK[]="OK";
const char tHelp[]="Aide";
const char tClose[]="Quitter";
//const char tFGUIContents[]="\177Contents";
//const char tFGUISearch[]="\177Search";
//const char tFGUIBack[]="\177Back";
//const char tFGUISearchFor[]="\177Search for:";
//const char tFGUICaseSensitive[]="\177Case Sensitive";
//const char tFGUISearchResults[]="Search Results";
//const char tFGUITextNotFound[]="Text not found.";
const char tFGUIDeleteFileX[]=_T("Supprimer %s?");
//
#if !defined(__LINUX__)
const char tFGUISVGAInitFailed[]="Initialisation SVGA echou�e";
const char tFGUINoVideo[]="Mode video non accessible";
//
//// Error by code to reduce memory requirements
const char tFGUIGraphicNotFound[]="ERR100";
const char tFGUIMemErrorFMsgBox[]="ERR101";
const char tFGUIGUIInitialized[]="ERR102";
const char tFGUIFontFileNotFound[]="ERR103";
const char tFGUIGraphicCorrupt[]="ERR104";
const char tFGUINoSelElement[]="ERR105";
const char tFGUIMemErrorForFText[]="ERR106";
const char tFGUIMemErrorFHelp[]="ERR107!";
const char tFGUIFEleGroupInitProb[]="ERR108";
const char tFGUIMemErrorFancyText[]="ERR109";
const char tFGUIFMenuBarOwner[]="ERR110";
const char tFGUIFTextEntNoMem[]="ERR111";
const char tFGUIFTextFileMemErr[]="ERR112";
const char tFGUIScrollBarProb[]="ERR113";
const char tFGUIListBoxMem[]="ERR114";
const char tFGUIComboMemErr[]="ERR115";
const char tFGUIFileDlgMemErr[]="ERR116";
#endif

//
//// FFileDialog
//const char tSelectFolder[] = "Select Folder";
//const char tOpen[] = "Open";
//const char tSaveAs[] = "Save As";
//const char tLTDirGT[] = "<DIR>";
//const char tHKName[] = "\177Name";
const char tHKSize[] = "&Taille";
const char tHKDateTime[] = "&Date/Heure";
const char tLoadingDirectoryPleaseWait[] = "(Chargement du dossier - attendez svp...)";
//const char tFileNotFound[] = "Fichier non trouv�.";
const char tOverwriteFile[] = "�craser \"%s\"?";
const char tUnableToOpen[] = "Impossible d'ouvrir \"%s\".";
const char tInvalidPath[] = "Chemin sp�cifi� invalide.";
//const char tInvalidExtension[] = "Invalid file extension specified.";
//
//// Display Settings Dialog
//const char tBackGround[]="Desktop";
//const char tTitleBar[]="Active Title Bar";
//const char tTilleBarText[]="Active Title Bar Text";
//const char tTitleBarInactive[]="Inactive Title Bar";
//const char tTitleBarTextInactive[]="Inactive Title Bar Text";
//const char tMenuFace[]="Menu";
//const char tMenuHighlight[]="Menu Highlight";
//const char tMenuShadow[]="Menu Shadow/Inactive Text";
//const char tMenuText[]="Menu Text";
//const char tMenuFaceSelected[]="Menu S�lection Bar";
//const char tMenuTextSelected[]="Menu S�lection Bar Text";
//const char tGroupFace[]="Dialog";
//const char tGroupHighlight[]="Dialog Highlight";
//const char tGroupShadow[]="Dialog Shadow One";
//const char tGroupOutline[]="Dialog Shadow Two";
//const char tGroupText[]="Dialog Text";
//const char tElementFace[]="Control";
//const char tElementHighlight[]="Control Highlight";
//const char tElementShadow[]="Control Shadow One";
//const char tElementOutline[]="Control Shadow Two/Check/Radio Button";
//const char tElementText[]="Control Text";
//const char tClientWindow[]="Child Window";
//const char tClientWindowText[]="Child Window Text";
//const char tClientWindowTextSelected[]="Child Window Selected Text";
//const char tClientWindowTextSelectedBG[]="Child Window Selected Background";
//const char tClientWindowTextLeftSelected[]="Child Window Inactive Selected Text";
//const char tClientWindowTextLeftSelectedBG[]="Child Window Inactive Selected Background";
//const char tClientWindowHighlight[]="Input Highlight";
//const char tClientWindowShadow[]="Input Shadow One";
//const char tClientWindowOutline[]="Input Window Shadow Two";
//const char tScrollBarBackground[]="Scroll Bar Background";
//const char tSampleLine[]="Sample Line %i"; // 24 chars or less
//
//const char tDisplaySettings[]="Display Settings";
//const char tChange[]="Change";
//const char tSample[]="Sample";
//const char tHKSample[]="\177Sample";
//const char tHKSampleMenu[]="Sample \177Menu";
const char tMode[]="Mode";
//const char tHKChange[]="\177Change";
//const char tHKChange2[]="C\177hange";
//const char tHKSave[]="\177Save";
//const char tHKRevert[]="\177Revert";
//const char tColorSelection[]="Color S�lection";

const TCHAR tHKStop[]="&Stop";

const TCHAR tHKBackup[]=_T("&Sauvegarde (compl�te)");
const TCHAR tHKBackupChanges[]=_T("Sauve&garde (modifications seules)");
const TCHAR tHKRestoreAuto[]=_T("Restauration (&Automatique)");
const TCHAR tHKRestoreNormal[]=_T("&Restauration (Normal)");
const TCHAR tHKValidate[]=_T("&V�rification");
const TCHAR tHKCopy[]=_T("&Copie");

const TCHAR tOperation[]=_T("Operation");
const TCHAR tHKExit[]=_T("Qui&ter");
const TCHAR tHKSettings[]=_T("&Param�tres");
const TCHAR tSettings[]=_T("Param�tres");

#if defined(__LINUX__)
const TCHAR tSelectOperationText[]=_T("Bienvenue dans Image For Linux.") NEWLINE
                                   NEWLINE
                                   _T("Merci de choisir l'op�ration que vous voulez effectuer :") NEWLINE
                                   NEWLINE;
#else
const TCHAR tSelectOperationText[]=_T("Bienvenue dans Image For DOS.") NEWLINE
                                   NEWLINE
                                   _T("Merci de choisir l'op�ration que vous voulez effectuer :") NEWLINE
                                   NEWLINE;
#endif

const TCHAR     tSelectDestFileName[]=_T("Entrez un nom de sauvegarde :");
const TCHAR     tSelectSourceBaseFileName[]=_T("S�lectionnez le prochain fichier :");
const TCHAR     tSelectSourceBaseFileNameBackup[]=_T("S�lectionnez le fichier de sauvegarde :");
const TCHAR     tSelectSourceFileNameRst[]=_T("S�lectionnez la sauvegarde a restaurer :");
const TCHAR     tSelectSourceFileNameVal[]=_T("S�lectionnez la sauvegarde a v�rifier :");

//const TCHAR     tSelectFDVorPVal[]=_T("Select the drive or partition(s) to validate:");
//const TCHAR     tSelectFDVorPRst[]=_T("Select the drive or partition(s) to restore:");
#if !defined(RESTORE_ONLY)
const TCHAR tSelectTypeOfBackup[]=_T("S�lectionnez le type de sauvegarde");
#endif

const char tHKC[]="&C";
const char tHKH[]="&H";
const char tHKS[]="&S";
const TCHAR tAlignment[]=_T("Alignement");

const TCHAR tHKSaveDefaults[]=_T("&Sauver defauts");
const TCHAR tHKShowCommand[]=_T("Ligne &commande");
const TCHAR tEG1G[]=_T("(ex. 1GiB)");
const TCHAR tHKInformation[]=_T("&Informations");
const TCHAR tHKAddVirtDrive[]=_T("Ajouter disque &virtuel");
const TCHAR tHKRemoveVirtDrive[]=_T("Supprimer disque &virtuel");
const TCHAR tHKGeometry[]=_T("&G�om�trie");
const TCHAR tHKCreateExtended[]=_T("Cr�&er �tendue");
const TCHAR tHKChangeDisk[]=_T("&Modifier disque");
const TCHAR tHKDelete[]=_T("&Supprimer");
const TCHAR tChangePartitioningType[]=_T("Modifier le type de partitionnement");
const TCHAR tHKGPT[]=_T("&GPT");
const TCHAR tHKEMBR[]=_T("&EMBR");
const TCHAR tHKMBR[]=_T("&MBR");
const TCHAR tHKSaveToFile[]=_T("&Sauvegarder dans un fichier");

#endif

#if !defined(RESTORE_ONLY)
const TCHAR tCompactCompleted[]=_T("Compactage de la partition termin�.");
const TCHAR tCompactFailedErrX[]=_T("�chec du compactage de la partition (%u)");
const TCHAR tCompact[]=_T("Compacter");
const TCHAR tHKCompact[]=_T("Co&mpacter");
const TCHAR tEnterSizeForCompactXMiBToXMiB[]=_T("Valeur de compactage en MiB (%u a %u)");
const TCHAR tNoLockForCompact[]=_T("La partition est en cours d'utilisation et ne peut pas �tre compact�e.");
const TCHAR tCompactCheckingddd[]=_T("V�rification du syst�me de fichier...");
const TCHAR tCompactingddd[]=_T("Compactage en cours...");
const TCHAR tCompactCheckingAgainddd[]=_T("Re-v�rification du syst�me de fichier...");
const TCHAR tErrorsCanOccurDuringProcessContinue[]=
          _T("Certaines conditions peuvent entrainer la perte de donn�es pendant ce type") NEWLINE
          _T("d'op�ration. Soyez certains d'avoir une sauvegarde de vos donn�es avant") NEWLINE
          _T("de continuer. Voulez-vous continuer ?");
#endif
const TCHAR tFree[]=_T("Libre");
const TCHAR tEditCommandLine[]=_T("Faites les modifications voulues dans la ligne de commande ci-dessous, et appuyez sur Entr�e :");
const TCHAR tEdit[]=_T("�dition");
const TCHAR tWipingGapOutsideOfPartitions[]=_T("Agrandissement des �carts inter-partitions...");
const TCHAR tRemovingHashFileDueToError[]=_T("Fichier de hash supprim� en raison d'une erreur.");
const TCHAR tBuildingHash[]=_T("Cr�ation du hash...");
const TCHAR tCompletedHashBuild[]=_T("Fin de la cr�ation du hash");
const TCHAR tProcessingC[]=_T("Op�ration : ");
const TCHAR tOldFileFormatNotSupported[]=_T("Le format du fichier est trop vieux pour l'op�ration demand�e.");
const TCHAR tCompressionNotBackwardsCompat[]=_T("Le niveau de compression s�lectionn� n'est pas r�tro-compatible.");

 #if defined(LINUX_GUI)
extern const TCHAR tUnableToStartThreadReasonX[]=_T("Impossible de d�marrer le processus. Erreur %u");
 #endif
 #if defined(__linux__)
extern const TCHAR tClosingSocket[]=_T("Fermeture des connections serveurs...");
 #endif
extern const TCHAR tWontFitExtended[]=_T("Une partition �tendue � cr�er n'est pas assez large pour contenir ses volumes.");
const TCHAR tCBAutoScaleRestrict[]=_T("&Restreindre r�ajustement auto.");
const TCHAR tCBAutoUpdateBootPart[]=_T("Modif. auto. &partition de boot");
const TCHAR tCBKeepFailed[]=_T("&Conserver sauvegardes incompl�tes");
const TCHAR tCBSearchOnAutoRestore[]=_T("Recherche auto &lecteur restaur.");
const TCHAR tRFTFailed[]=_T("Impossible d'�crire la premi�re piste");
const TCHAR tExcludeListInUseFromXContainsX[]=_T("ATTENTION : des donn�es de fichiers sont exclues par la liste sous %s.\n%s");
const TCHAR tUnableToLoadFileXRX[]=_T("Impossible de charger les donn�es du fichier %s (raison : %Xh)\n");
const TCHAR tFileXIsTooLargeMaxIsX[]=_T("Le fichier %s est plus large que la taille max support�e (%u)");
const TCHAR tWarningAllFilesExcludedNotRemoved[]=_T("ATTENTION : certains fichiers exclus de la sauvegarde ne peuvent pas �tre supprim�s ou vid�s. Les donn�es dans ces fichiers seront ind�finies.");
const TCHAR tCombiningFiles[]=_T("Consolidation des fichiers...");
const TCHAR tCompletedCombiningFiles[]=_T("Consolidation des fichiers termin�e");
const TCHAR tbuildhash[]="hash cr��";
const TCHAR tcombinefiles[]="consolider fichiers";
const TCHAR tCreateFailedS[]=_T("Impossible de cr�er le fichier %s");
const TCHAR tErrorXProcessingFileX[]=_T("Erreur %u survenue pendant le traitement du fichier %s");
const TCHAR tCLUnableToLoadBaseOfFileXX[]=_T("Impossible de charger le fichier %s base sur: %s") NEWLINE;
const TCHAR tNewMBRWritten[]=_T("Nouveau MBR �crit");
const TCHAR tDeletingX[]=_T("Suppression %s");
const TCHAR tEnterPasswordForX[]=_T("Entrez mot de passe pour fichier %s");
const TCHAR tNewBackupFileInUse[]=_T("Le nom de fichier est d�j� utilis� pour cette op�ration et ne peut pas �tre �cras�.");
const TCHAR tActiveBoot[]=_T("**Active**");
const TCHAR tCBCompletionAlarm[]=_T("Si&gnal de fin");
const TCHAR tCLInvalidParamXMustBeEariler[]=_T("Le param�tre '%s' doit �tre utilis� plus t�t dans la ligne de commande.") NEWLINE;
const TCHAR tCBUseSigCL[]=_T("Montrer &ID dsk dans ligne commande");
const TCHAR tGatheringInformationddd[]=_T("R�cuperation d'informations...");
const TCHAR tProcessingExcludeListddd[]=_T("Traitement de la liste d'exclusion...");
const TCHAR tComparingC[]=_T("Comparaison :");
const TCHAR tCBCacheResize[]=_T("&Redimensionner cache");
#if defined(INJECTfilesAvailable)
const TCHAR tIncludeListInUseFromXContainsX[]=_T("ATTENTION : inclure des fichiers selon la liste dans %s.\n%s");
const TCHAR tSkippingLineX[]=_T("Ignorer %s");
const TCHAR tCopyingXToX[]=_T("Copie de %s vers %s");
const TCHAR tCopyingX[]=_T("Copie du fichier %s");
const TCHAR tUnableToCreateDirX[]=_T("Impossible de cr�er le r�pertoire %s");
const TCHAR tErrorReadingFileX[]=_T("Erreur de lecture du fichier %s");
const TCHAR tErrorWritingFileX[]=_T("Erreur d'�criture du fichier %s");
#endif
#if defined(UEFI_C_SOURCE)
  const TCHAR tUEFIDevNoSupport[]=_T("Le syst�me UEFI n'a pas le support d�sir� pour cette op�ration.\n")
                                  _T("Contactez le fabricant pour obtenir une mise � jour UEFI (logiciel) courante\n")
                                  _T("avec des fonctions compl�tes.\n");
#endif

#if !defined(RESTORE_ONLY)
const TCHAR tSimpleFileDrive[]=_T("Enregistrer sauvegarde sur");
const TCHAR tSimpleSourceDrive[]=_T("S�lectionnez le lecteur � sauvegarder");
const TCHAR tUnableToSetupNextBackup[]=_T("Impossible de configurer automatiquement la sauvegarde");
const TCHAR tUnableToAutoSetupHelp[]=_T("Supprimez l'espace de stockage pour en permettre un nouveau d'�tre cr��, ou appuyez sur �chap jusqu'� revenir au menu principal, choisissez \"Param�tres g�n�raux\", et desactivez \"Op�rations simples\"");
const TCHAR tUnableToConfigureNextBackup[]=_T("Impossible de d�terminer automatiquement la prochaine sauvegarde");
const TCHAR tUnableToCreateDeviceStoreReasonX[]=_T("Impossible de cr�er l'espace pour la sauvegarde sur le lecteur choisi (%Xh).");
const TCHAR tSimpleCopySrc[]=_T("Select the hard drive to copy:");
//const TCHAR tSimpleNoSource[]=_T("Please select a specific drive to backup by highlighting it, then press enter.");
const TCHAR tSimpleModeAutoCompactQuestion[]=_T("\n\nHowever, it appears that the source data can be compatacted to fit.\nCompacting is typically a safe operation but does alter the\nsource drive.  You should have a known good complete backup before\ncompating just to be extra safe.\n\nWould you like to have the source data compacted?");

const TCHAR tCompactSNToNS[]=_T("Compact %.25s (%s) to %s %s");
#endif
const TCHAR tSucceeded[]=_T("Succeeded");
const TCHAR tFailed[]=_T("Failed");

const TCHAR tSimpleNoBackupSelected[]=_T("Merci de surligner une sauvegarde sp�cifique, puis appuyez sur Entr�e.");
const TCHAR tBackupsFromThisComputer[]=_T("Sauvegarde depuis cet ordinateur");
const TCHAR tBackupsFromAnotherComputer[]=_T("Sauvegarde depuis un autre ordinateur");
const TCHAR tUnableToSetupRestoreValidate[]=_T("Impossible de pr�parer l'op�ration demand�e (%Xh). Cela peut �tre d� � un fichier manquant, des probl�mes mat�riels, ou un probl�me d�j� report� avant ce message. Essayez une sauvegarde diff�rente, ou appuyez sur �chap jusqu'� revenir au menu principal, choisissez \"Param�tres g�n�raux\", et desactivez \"Op�rations simples\"");
const TCHAR tSimpleSelectBackupRestore[]=_T("S�lectionnez la sauvegarde � restaurer");
const TCHAR tSimpleSelectBackupValidate[]=_T("S�lectionnez la sauvegarde � v�rifier");
const TCHAR tCBSimpleOperations[]=_T("Op�rations &simples");
const TCHAR tNoBackupFilesFound[]=_T("Pas de sauvegarde trouv�e.\n\nMerci de v�rifier que le lecteur contenant les sauvegardes est branch�.");
const TCHAR tDeletingXForFreeSpace[]=_T("Suppression %s pour cr�er de l'espace.");
const TCHAR tDeleteFailed[]=_T("�chec de la suppression.");
const TCHAR tMultipleStoresFound[]=_T("Plusieurs espaces de stockage trouv�s.");
#if defined(_WIN32)
const TCHAR tNoRestoreOverWindowsS[]=_T("ARR�T : Windows tourne sur le lecteur � restaurer.\n\nVous ne pouvez pas restaurer Windows lorsqu'il est en cours d'utilisation.\nVous devez cr�er et utiliser un disque de r�cup�ration comme expliqu� dans le manuel.\n\nDes tutoriels sont �galement disponibles sur %s");
const TCHAR tFlushingData[]=_T("Lib�ration des donn�es de la RAM.  Merci de patienter...");
#endif
#if !defined(DOS_GUI) && !defined(LINUX_GUI)
const TCHAR tSettingsDisabled[]=_T("Cette option a �t� desactiv�e.");
#endif
const TCHAR tNewName[]=_T("&New Name");
const TCHAR tCBCSigUT[]=_T("Prefer Target Disk ID on &Change");
#if defined(__LINUX__)
const TCHAR tNoRestoreTargetHasMountedPartitions[]=_T("Abort: Linux mounted partition(s) will not be overwritten");
#endif
const TCHAR tCLProcessingParameterXFailed[]=_T("Processing Parameter %s Failed.");
#if defined(_WIN32) || defined(__LINUX__)
const TCHAR tWaitingForMulticast[]=_T("Waiting for multicast...");
#endif
const TCHAR tCLParametersIncompatible[]=_T("Parameters are not compatible.");
const TCHAR tDataValidationFailed[]=_T("FAIL: Data did not pass validation.");
const TCHAR tDeviceCacheWriteFail[]=_T("The device containing the .TBI file failed to write all sector data.\n\nAll file systems on the device should be checked for errors.");
const TCHAR tIncrementalChainWarningCountNOfN[]=_T("Warning: The chain of incremental backup files has reached %u which exceeds the threshold of %u.  It is recommended that you consolidate the chain or start a new full backup.");
const TCHAR tSummaryDependencyCountN[]=_T("Depends on %u backup(s).");
const TCHAR tSummaryWarningDependencyN[]=_T("Warning: Depends on %u backups.  Consolidation recommended.");
const TCHAR tBackupChanges[]=_T("Backup Changes");
const TCHAR tSourceHasNoDRATForB4BValidate[]=_T("Validate Byte-for-Byte may fail because the source SSD drive does not support DRAT.");
#if !defined(RESTORE_ONLY)
const TCHAR tOptNotCompatWithMDHash[]=_T("Metadata hash file creation ignored due to incompatible option.");
const TCHAR tOptNotCompatWithSecHash[]=_T("Sector hash file creation ignored due to incompatible option.");
#endif
const TCHAR tRecoveryErrorCountN[]=_T("Warning: Recovery mode encountered %lu problems.");
const TCHAR tCBMDFullDirContents[]=_T("Use Directory Data in &Metadata Hash");
#if defined(LINUX_GUI)
const TCHAR tCancelRequested[]=_T("Cancel Request Received. Please Wait...");
#endif
#if defined(_WIN32)
const TCHAR tMDHashSkipNoDriver[]=_T("Metadata has creation ignored due to missing driver.");
#endif
const TCHAR tOptTrimTarget[]=_T("&Unmap/Trim Target Area");
const TCHAR tDeallocateULLtoULLFailed[]=_T("Unmap/Trim LBA %llu - %llu Failed");
const TCHAR tDeallocating[]=_T("Unmapping/Trimming Sectors...");
const TCHAR tDeallocateULLtoULL[]=_T("Unmap/Trim LBA %llu - %llu");
const TCHAR tHiddenGPTE[]=_T("Hidden");
