The License Agreements in this directory and related subdirectories 
only apply to the Linux OS components included on the boot media and
NOT Image for Linux.
